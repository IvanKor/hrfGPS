#define _CRT_SECURE_NO_WARNINGS

#include "hackrfgps.h"
#include <hackrf.h>

// for _getch used in Windows runtime.
#ifdef WIN32
#include <conio.h>
#include "getopt.h"
#else
#include <unistd.h>
#endif

extern hackrf_device_list_t *list;
extern hackrf_device* device;

extern int hackrfgps_open(void);

#define FREQ_ONE_MHZ (1000000ull)
#define BASEBAND_FILTER_BW_MIN (1750000)  /* 1.75 MHz min value */
#define BASEBAND_FILTER_BW_MAX (28000000) /* 28 MHz max value */
#define U64TOA_MAX_DIGIT (31)
typedef struct
{
	char data[U64TOA_MAX_DIGIT + 1];
} t_u64toa;

t_u64toa ascii_u64_data1;
t_u64toa ascii_u64_data2;

bool transmit_gps = false;
volatile bool do_exit_this_gps = false;
volatile bool exit_this_gps = false;
static transceiver_mode_t hackrf_mode = TRANSCEIVER_MODE_RX;
uint32_t sample_rate_gps_hz;
uint32_t baseband_filter_bw_hackrf_hz = 0;
uint64_t freq_gps_hz;
uint32_t crystal_correct_ppm = 0;
uint32_t amp_enable = 0;
FILE* fd = NULL;

extern FILE* fd;

#ifdef _WIN32

#ifdef _MSC_VER

#ifdef _WIN64
typedef int64_t ssize_t;
#else
typedef int32_t ssize_t;
#endif
#endif
#endif

//volatile sim_t s;
sim_t s;
size_t samples_populated;
int8_t *tx_buffer_current;

int parse_u32(char* s, uint32_t* const value) {
	uint_fast8_t base = 10;
	char* s_end;
	uint64_t ulong_value;

	if (strlen(s) > 2) {
		if (s[0] == '0') {
			if ((s[1] == 'x') || (s[1] == 'X')) {
				base = 16;
				s += 2;
			}
			else if ((s[1] == 'b') || (s[1] == 'B')) {
				base = 2;
				s += 2;
			}
		}
	}

	s_end = s;
	ulong_value = strtoul(s, &s_end, base);
	if ((s != s_end) && (*s_end == 0)) {
		*value = (uint32_t)ulong_value;
		return HACKRF_SUCCESS;
	}
	else {
		return HACKRF_ERROR_INVALID_PARAM;
	}
}



static char *stringrev(char *str)
{
	char *p1, *p2;

	if (!str || !*str)
		return str;

	for (p1 = str, p2 = str + strlen(str) - 1; p2 > p1; ++p1, --p2)
	{
		*p1 ^= *p2;
		*p2 ^= *p1;
		*p1 ^= *p2;
	}
	return str;
}

char* u64toa(uint64_t val, t_u64toa* str)
{
#define BASE (10ull) /* Base10 by default */
	uint64_t sum;
	int pos;
	int digit;
	int max_len;
	char* res;

	sum = val;
	max_len = U64TOA_MAX_DIGIT;
	pos = 0;

	do
	{
		digit = (sum % BASE);
		str->data[pos] = digit + '0';
		pos++;

		sum /= BASE;
	} while ((sum>0) && (pos < max_len));

	if ((pos == max_len) && (sum>0))
		return NULL;

	str->data[pos] = '\0';
	res = stringrev(str->data);

	return res;
}


void init_sim(sim_t *s)
{
//	s->tx.dev = NULL;
	pthread_mutex_init(&(s->tx.lock), NULL);
	//s->tx.error = 0;

	pthread_mutex_init(&(s->gps.lock), NULL);
	//s->gps.error = 0;
	s->gps.ready = 0;
	pthread_cond_init(&(s->gps.initialization_done), NULL);

	s->status = 0;
	s->head = 0;
	s->tail = 0;
	s->sample_length = 0;

	pthread_cond_init(&(s->fifo_write_ready), NULL);
	pthread_cond_init(&(s->fifo_read_ready), NULL);

	s->time = 0.0;
}

size_t get_sample_length(sim_t *s)
{
	long length;

	length = s->head - s->tail;
	if (length < 0)
		length += FIFO_LENGTH;

	return((size_t)length);
}

size_t fifo_read(int8_t *buffer, size_t samples, sim_t *s)
{
	size_t length;
	size_t samples_remaining;
	int8_t *buffer_current = buffer;

	length = get_sample_length(s);

	if (length < samples)
		samples = length;

	length = samples; // return value

	samples_remaining = FIFO_LENGTH - s->tail;

	if (samples > samples_remaining) {
		memcpy(buffer_current, &(s->fifo[s->tail * 2]), samples_remaining * sizeof(int8_t) * 2);
		s->tail = 0;
		buffer_current += samples_remaining * 2;
		samples -= samples_remaining;
	}

	memcpy(buffer_current, &(s->fifo[s->tail * 2]), samples * sizeof(int8_t) * 2);
	s->tail += (long)samples;
	if (s->tail >= FIFO_LENGTH)
		s->tail -= FIFO_LENGTH;

	return(length);
}

bool is_finished_generation(sim_t *s)
{
	return s->finished;
}

int is_fifo_write_ready(sim_t *s)
{
	int status = 0;

	s->sample_length = get_sample_length(s);
	if (s->sample_length < NUM_IQ_SAMPLES)
		status = 1;

	return(status);
}

int tx_callback(hackrf_transfer* transfer) {

		tx_buffer_current = s.tx.buffer;
		unsigned int buffer_samples_remaining = SAMPLES_PER_BUFFER;

		while (buffer_samples_remaining > 0) {

			pthread_mutex_lock(&(s.gps.lock));
			while (get_sample_length(&s) == 0)
			{
				pthread_cond_wait(&(s.fifo_read_ready), &(s.gps.lock));
			}
			samples_populated = fifo_read(tx_buffer_current,
				buffer_samples_remaining,
				&s);
			pthread_mutex_unlock(&(s.gps.lock));

			pthread_cond_signal(&(s.fifo_write_ready));
			// Advance the buffer pointer.
			buffer_samples_remaining -= (unsigned int)samples_populated;
			tx_buffer_current += (2 * samples_populated);
		}

		// If there were no errors, transmit the data buffer.
		memcpy(transfer->buffer, s.tx.buffer, samples_populated*2);
		if (is_fifo_write_ready(&s)) {

		}
		else if (is_finished_generation(&s))
		{
			return -1;
		}
		if (do_exit_this_gps)
		{
			return -1;
		}
 return 0;
}

int start_gps_task(sim_t *s)
{
	int status;

	status = pthread_create(&(s->gps.thread), NULL, gps_task, s);

	return(status);
}

void usage(void)
{
	printf("Usage: hackrfgps [options]\n"
		"Options:\n"
		"  -e <gps_nav>     RINEX navigation file for GPS ephemerides (required)\n"
		"  -u <user_motion> User motion file (dynamic mode)\n"
		"  -g <nmea_gga>    NMEA GGA stream (dynamic mode)\n"
		"  -l <location>    Lat,Lon,Hgt (static mode) e.g. 35.274,137.014,100\n"
		"  -t <date,time>   Scenario start time YYYY/MM/DD,hh:mm:ss\n"
		"  -T <date,time>   Overwrite TOC and TOE to scenario start time\n"
		"  -d <duration>    Duration [sec] (max: %.0f)\n"
		"  -a <amp_enable>  RX/TX RF amplifier 1=Enable, 0=Disable.\n"
		"  -x <tx_vga1>     TX VGA (IF) gain, 0-47dB, 1dB steps, (default: %d)\n"
		"  -i               Interactive mode: North='%c', South='%c', East='%c', West='%c'\n"
		"  -I               Disable ionospheric delay for spacecraft scenario\n",
		((double)USER_MOTION_SIZE)/10.0, 
		TX_VGA1,
		NORTH_KEY, SOUTH_KEY, EAST_KEY, WEST_KEY);

	return;
}
BOOL WINAPI sighandler_gps(int signum)
{
	if (CTRL_C_EVENT == signum) {
		fprintf(stdout, "\nUser press 'Ctrl+C', wait ...\n");
		do_exit_this_gps = true;
		return TRUE;
	}
	return FALSE;
}

int main(int argc, char *argv[])
{
	char *devstr = NULL;
	int result;
	double duration;
	datetime_t t0;

	int txvga1 = TX_VGA1;
	if (argc<3)
	{
		usage();
		exit(1);
	}
	s.finished = false;

	s.opt.navfile[0] = 0;
	s.opt.umfile[0] = 0;
	s.opt.g0.week = -1;
	s.opt.g0.sec = 0.0;
	s.opt.iduration = USER_MOTION_SIZE;
	s.opt.verb = TRUE;
	s.opt.nmeaGGA = FALSE;
	s.opt.staticLocationMode = TRUE; // default user motion
	s.opt.llh[0] = 40.7850916 / R2D;
	s.opt.llh[1] = -73.968285 / R2D;
	s.opt.llh[2] = 100.0;
	s.opt.interactive = FALSE;
	s.opt.timeoverwrite = FALSE;
	s.opt.iono_enable = TRUE;

	while ((result=getopt(argc,argv,"e:u:g:l:T:t:d:x:a:iI"))!=-1)
	{
		switch (result)
		{
		case 'e':
			strcpy(s.opt.navfile, optarg);
			break;
		case 'u':
			strcpy(s.opt.umfile, optarg);
			s.opt.nmeaGGA = FALSE;
			s.opt.staticLocationMode = FALSE;
			break;
		case 'g':
			strcpy(s.opt.umfile, optarg);
			s.opt.nmeaGGA = TRUE;
			s.opt.staticLocationMode = FALSE;
			break;
		case 'l':
			// Static geodetic coordinates input mode
			// Added by scateu@gmail.com
			s.opt.nmeaGGA = FALSE;
			s.opt.staticLocationMode = TRUE;
			sscanf(optarg,"%lf,%lf,%lf",&s.opt.llh[0],&s.opt.llh[1],&s.opt.llh[2]);
			s.opt.llh[0] /= R2D; // convert to RAD
			s.opt.llh[1] /= R2D; // convert to RAD
			break;
		case 'T':
			s.opt.timeoverwrite = TRUE;
			if (strncmp(optarg, "now", 3)==0)
			{
				time_t timer;
				struct tm *gmt;
				
				time(&timer);
				gmt = gmtime(&timer);

				t0.y = gmt->tm_year+1900;
				t0.m = gmt->tm_mon+1;
				t0.d = gmt->tm_mday;
				t0.hh = gmt->tm_hour;
				t0.mm = gmt->tm_min;
				t0.sec = (double)gmt->tm_sec;

				date2gps(&t0, &s.opt.g0);

				break;
			}
		case 't':
			sscanf(optarg, "%d/%d/%d,%d:%d:%lf", &t0.y, &t0.m, &t0.d, &t0.hh, &t0.mm, &t0.sec);
			if (t0.y<=1980 || t0.m<1 || t0.m>12 || t0.d<1 || t0.d>31 ||
				t0.hh<0 || t0.hh>23 || t0.mm<0 || t0.mm>59 || t0.sec<0.0 || t0.sec>=60.0)
			{
				printf("ERROR: Invalid date and time.\n");
				exit(1);
			}
			t0.sec = floor(t0.sec);
			date2gps(&t0, &s.opt.g0);
			break;
		case 'd':
			duration = atof(optarg);
			if (duration<0.0 || duration>((double)USER_MOTION_SIZE)/10.0)
			{
				printf("ERROR: Invalid duration.\n");
				exit(1);
			}
			s.opt.iduration = (int)(duration*10.0+0.5);
			break;
		case 'x':
			txvga1 = atoi(optarg);

			if (txvga1<TXVGA1_GAIN_MIN)
				txvga1 = TXVGA1_GAIN_MIN;
			else if (txvga1>TXVGA1_GAIN_MAX)
				txvga1 = TXVGA1_GAIN_MAX;
		case 'i':
			s.opt.interactive = TRUE;
			break;
		case 'a':
			//amp = true;
			result = parse_u32(optarg, &amp_enable);
			break;
		case 'I':
			s.opt.iono_enable = FALSE; // Disable ionospheric correction
			break;
		case ':':
		case '?':
			usage();
			exit(1);
		default:
			break;
		}
	}

	if (s.opt.navfile[0]==0)
	{
		printf("ERROR: GPS ephemeris file is not specified.\n");
		exit(1);
	}

	if (s.opt.umfile[0]==0 && !s.opt.staticLocationMode)
	{
		printf("ERROR: User motion file / NMEA GGA stream is not specified.\n");
		printf("You may use -l to specify the static location directly.\n");
		exit(1);
	}

	// Initialize simulator
	init_sim(&s);

	// Allocate TX buffer to hold each block of samples to transmit.
	s.tx.buffer = (int8_t *)malloc(SAMPLES_PER_BUFFER * sizeof(int8_t) * 2); // for 8-bit I and Q samples
	
	if (s.tx.buffer == NULL) {
		fprintf(stderr, "Failed to allocate TX buffer.\n");
		goto out;
	}

	// Allocate FIFOs to hold 0.1 seconds of I/Q samples each.
	s.fifo = (int8_t *)malloc(FIFO_LENGTH * sizeof(int8_t) * 2); // for 8-bit I and Q samples

	if (s.fifo == NULL) {
		fprintf(stderr, "Failed to allocate I/Q sample buffer.\n");
		goto out;
	}

	// Initializing device.
	printf("Opening and initializing device...\n");
	
	s.status = hackrfgps_open();
	if (s.status != 0) {
		fprintf(stderr, "Failed to open hackrf ...\n");
		goto out;
	}

	transmit_gps = true;
	if (amp_enable > 1)
	{
		fprintf(stderr, "argument error: amp_enable shall be 0 or 1.\n");
		usage();
		goto out;
	}

	if (transmit_gps) {
		hackrf_mode = TRANSCEIVER_MODE_TX;
	}
	sample_rate_gps_hz = TX_SAMPLERATE;
	freq_gps_hz = TX_FREQUENCY;
	/* Compute default value depending on sample rate */
	baseband_filter_bw_hackrf_hz = hackrf_compute_baseband_filter_bw_round_down_lt(sample_rate_gps_hz);
	//meby this ...	baseband_filter_bw_hackrf_hz = hackrf_compute_baseband_filter_bw(sample_rate_gps_hz);

	if (baseband_filter_bw_hackrf_hz > BASEBAND_FILTER_BW_MAX) {
		fprintf(stderr, "argument error: baseband_filter_bw_hz must be less or equal to %u Hz/%.03f MHz\n",
			BASEBAND_FILTER_BW_MAX, (float)(BASEBAND_FILTER_BW_MAX / FREQ_ONE_MHZ));
		goto out;
	}

	if (baseband_filter_bw_hackrf_hz < BASEBAND_FILTER_BW_MIN) {
		fprintf(stderr, "argument error: baseband_filter_bw_hz must be greater or equal to %u Hz/%.03f MHz\n",
			BASEBAND_FILTER_BW_MIN, (float)(BASEBAND_FILTER_BW_MIN / FREQ_ONE_MHZ));
		goto out;
	}

	// Change the freq and sample rate to correct the crystal clock error.
	sample_rate_gps_hz = (uint32_t)((double)sample_rate_gps_hz * (1000000 - crystal_correct_ppm) / 1000000 + 0.5);
	freq_gps_hz = freq_gps_hz * (1000000 - crystal_correct_ppm) / 1000000;

	SetConsoleCtrlHandler((PHANDLER_ROUTINE)sighandler_gps, TRUE);
	fprintf(stderr, "call hackrf_sample_rate_set(%u Hz/%.03f MHz)\n", sample_rate_gps_hz, ((float)sample_rate_gps_hz / (float)FREQ_ONE_MHZ));
	
	result = hackrf_set_sample_rate_manual(device, sample_rate_gps_hz, 1);
	if (result != HACKRF_SUCCESS) {
		fprintf(stderr, "hackrf_sample_rate_set() failed: %s (%d)\n", hackrf_error_name(result), result);
		goto out;
	}
	fprintf(stderr, "call hackrf_baseband_filter_bandwidth_set(%d Hz/%.03f MHz)\n",
		baseband_filter_bw_hackrf_hz, ((float)baseband_filter_bw_hackrf_hz / (float)FREQ_ONE_MHZ));
	result = hackrf_set_baseband_filter_bandwidth(device, baseband_filter_bw_hackrf_hz);
	if (result != HACKRF_SUCCESS) {
		fprintf(stderr, "hackrf_baseband_filter_bandwidth_set() failed: %s (%d)\n", hackrf_error_name(result), result);
		goto out;
	}


	fprintf(stderr, "call hackrf_set_freq(%s Hz/%.03f MHz)\n",
		u64toa(freq_gps_hz, &ascii_u64_data1), ((double)freq_gps_hz / (double)FREQ_ONE_MHZ));
	result = hackrf_set_freq(device, freq_gps_hz);
	if (result != HACKRF_SUCCESS) {
		fprintf(stderr, "hackrf_set_freq() failed: %s (%d)\n", hackrf_error_name(result), result);
		goto out;
	}

	if ((amp_enable == 0)|(amp_enable == 1)) {
		fprintf(stderr, "call hackrf_set_amp_enable(%u)\n", amp_enable);
		result = hackrf_set_amp_enable(device, (uint8_t)amp_enable);
		if (result != HACKRF_SUCCESS) {
			fprintf(stderr, "hackrf_set_amp_enable() failed: %s (%d)\n", hackrf_error_name(result), result);
			usage();
			return EXIT_FAILURE;
		}
	}

	fprintf(stderr, "call hackrf_set_txvga_gain(%u)\n", txvga1);
	result = hackrf_set_txvga_gain(device, txvga1);
	result |= hackrf_start_tx(device, tx_callback, NULL);
	if (result != HACKRF_SUCCESS) {
		fprintf(stderr, "hackrf_start_tx() failed: %s (%d)\n", hackrf_error_name(result), result);
		goto out;
	}



	// Start GPS task.
	s.status = start_gps_task(&s);
	if (s.status < 0) {
		fprintf(stderr, "Failed to start GPS task.\n");
		goto out;
	}
	else
		printf("Creating GPS task...\n");

	// Wait until GPS task is initialized
	pthread_mutex_lock(&(s.tx.lock));
	while (!s.gps.ready)
		pthread_cond_wait(&(s.gps.initialization_done), &(s.tx.lock));
	pthread_mutex_unlock(&(s.tx.lock));

	// Fillfull the FIFO.
	if (is_fifo_write_ready(&s))
		pthread_cond_signal(&(s.fifo_write_ready));

	// Running...
	printf("Running...\n");
	printf("Press 'Ctrl+C' to abort.\n");

	pthread_join(s.tx.thread, NULL);
	while ((hackrf_is_streaming(device) == HACKRF_TRUE) &&
		(exit_this_gps == false))
	{
		Sleep(50);

	}

	printf("\nDone!\n");

	// Disable TX module and shut down underlying TX stream.
out:
	// Free up resources
	if (s.tx.buffer != NULL)
		free(s.tx.buffer);

	if (s.fifo != NULL)
		free(s.fifo);

	if (device != NULL){
		printf("Closing device...\n");


		result = hackrf_is_streaming(device);
		if (do_exit_this_gps)
		{
		}
		else {
			fprintf(stderr, "\nExiting... hackrf_is_streaming() result: %s (%d)\n", hackrf_error_name(result), result);
		}

		if (transmit_gps & (device != NULL))
		{
			result = hackrf_stop_tx(device);
			if (result != HACKRF_SUCCESS) {
				fprintf(stderr, "hackrf_stop_tx() failed: %s (%d)\n", hackrf_error_name(result), result);
			}
			else {
				fprintf(stderr, "hackrf_stop_tx() done\n");
			}
		}
		fflush(stdout);
	}
	result = hackrf_close(device);
	if (result != HACKRF_SUCCESS) {
		fprintf(stderr, "hackrf_close() failed: %s (%d)\n",
			hackrf_error_name(result), result);
	}
	hackrf_device_list_free(list);
	hackrf_exit();


	return(0);
}
//-v - e brdc3050.16n - b 8 - s 2600000 - l 50.050926, 36.325433, 100 //Okk !!!Use this
//hackrf_transfer -t gpssim.bin -f 1575420000 -s 2600000 -a 1 -x 10
//hackrf_transfer -t gpssim.bin -f 1575420000 -s 2600000 -a 0 -x 0 //!!! this
//-e brdc3490.16n -l 50.050926,36.325433,100
