﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using MissionPlanner.Comms;
using System.Security.Cryptography;

namespace UBLOXDump
{
    internal class Program
    {
        private static readonly BinaryWriter bw =
            new BinaryWriter(File.Open("data.raw", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.Read));

        private static byte UBX_class;
        private static byte UBX_id;
        private static byte UBX_payload_length_hi;
        private static readonly int UBX_MAXPAYLOAD = 1000;
        private static byte ck_a;
        private static byte ck_b;
        private static byte UBX_payload_length_lo;
        private static byte UBX_ck_a;
        private static byte UBX_ck_b;
        private static int UBX_payload_counter;
        private static readonly byte[] UBX_buffer = new byte[256];
        private static int UBX_step;
        private static uploadreq req;
        private static uploadreq_sec req_sec;

        //http://gps.0xdc.ru/wiki/doku.php?id=u-blox_undocumented_messages

        public class msginfo
        {
            public string name;
            public byte cl;
            public byte id;

            public msginfo()
            {
                
            }

            public msginfo(string name, byte cl, byte id)
            {
                this.name = name;
                this.cl = cl;
                this.id = id;
            }
        }

        /* 
*v8 09 0b - set addr // B5 62 09 0B 05 00 00 00 80 00 01 9A 4D
*   09 0c - data
*   09 0d
*   09 07 - safeboot
*   09 0e - finish
*   09 06 - identify
*   09 21 - UPD-DOWNL
*   09 08 - start addr ? // B5 62 09 08 04 00 00 00 80 00 95 98
*   09 20 - UPD-UPLOAD
*/
        static byte[] sha256(byte[] seed, byte[] packet)
        {
            using (SHA256Managed signit = new SHA256Managed())
            {
                signit.TransformBlock(seed, 0, seed.Length, null, 0);
                signit.TransformFinalBlock(packet, 0, packet.Length);
                var ctx = signit.Hash;

                return ctx;
            }
        }


        private static void pollmessage(Stream port, byte[] header, byte clas, byte subclass)
        {
            //B5 62 02 31 00 00 33 9B 

            byte[] datastruct1 = {clas, subclass, 0, 0};

            var checksum1 = ubx_checksum(datastruct1, datastruct1.Length);

            port.Write(header, 0, header.Length);
            port.Write(datastruct1, 0, datastruct1.Length);
            port.Write(checksum1, 0, checksum1.Length);
        }

        private static void turnon(Stream port, byte[] header, byte clas, byte subclass)
        {
            //B5 62 06 01 03 00 02 30 01 3D A6

            byte[] datastruct1 = {0x6, 0x1, 0x3, 0x0, clas, subclass, 1};

            var checksum1 = ubx_checksum(datastruct1, datastruct1.Length);

            port.Write(header, 0, header.Length);
            port.Write(datastruct1, 0, datastruct1.Length);
            port.Write(checksum1, 0, checksum1.Length);
        }

        private static void Main(string[] args)
        {
            ICommsSerial port;// = /*new TcpSerial();*/ //new SerialPort("com35" ,115200);
            port = new MissionPlanner.Comms.SerialPort();

            //port.PortName = "com9";
            port.PortName = "com2";
            port.BaudRate = 9600;

            // mp internal pass
            //port.PortName = "127.0.0.1";
            //port.BaudRate = 500;

            port.ReadBufferSize = 1024*1024;

            port.Open();

            /*
             * 
             * ?????
0x00800000 0x80000 flash
0x20000000 0x20000 ram
0x20080000 0x20000 ram
0x00200000 0x8000 rom
             * 
             */

            var rxmraw6m = new downloadreq();
            rxmraw6m.clas = 0x9;
            rxmraw6m.subclass = 0x1;
            rxmraw6m.length = 0x10;
            rxmraw6m.flags = 0;
            rxmraw6m.startaddr = 0x16c8;
            rxmraw6m.data = new byte[] {0x97, 0x69, 0x21, 0x00, 0x00, 0x00, 0x02, 0x10};

            var rxmsfrb6m = new downloadreq();
            rxmsfrb6m.clas = 0x9;
            rxmsfrb6m.subclass = 0x1;
            rxmsfrb6m.length = 0x10;
            rxmsfrb6m.flags = 0;
            rxmsfrb6m.startaddr = 0x190c;
            rxmsfrb6m.data = new byte[] {0x83, 0x69, 0x21, 0x00, 0x00, 0x00, 0x02, 0x11};

            var rxmraw6h = new downloadreq();
            rxmraw6h.clas = 0x9;
            rxmraw6h.subclass = 0x1;
            rxmraw6h.length = 0x10;
            rxmraw6h.flags = 0;
            rxmraw6h.startaddr = 0x40F4;
            rxmraw6h.data = new byte[] {0xe7, 0xb9, 0x81, 0x00, 0x00, 0x00, 0x02, 0x10};

            var rxmsfrb6h = new downloadreq();
            rxmsfrb6h.clas = 0x9;
            rxmsfrb6h.subclass = 0x1;
            rxmsfrb6h.length = 0x10;
            rxmsfrb6h.flags = 0;
            rxmsfrb6h.startaddr = 0x4360;
            rxmsfrb6h.data = new byte[] {0xd3, 0xb9, 0x81, 0x00, 0x00, 0x00, 0x02, 0x11};

            byte[] turnonbytes = {0, 1, 0, 0, 0, 0, 0, 0};

            byte[] header = {0xb5, 0x62};

            /*
             * Load FW binary 'C:\Users\hog\Downloads\NL602-patched-fw (1).bin'
            Binary check success, G60 image valid.
            Version: 7.03 (45970) Mar 17 2011 16:26:24
            FLASH Base:          0x800000
            FW Base:             0x800000
            FW Start:            0x800048
            FW End:              0x860AD4
            FW Size:             0x60ADC
             * 
             * Identifying Flash
            Flash: ManID=0x90, DevID=0x90
             * 
             * firmware: 0x200000
             */

            //turnon(port, header, 2, 0x20);
            //turnon(port, header, 2, 0x12);
            //turnon(port, header, 2, 0x23);
            //turnon(port, header, 2, 0x24);
            //turnon(port, header, 2, 0x51);
            //turnon(port, header, 2, 0x52);

            // turnon(port.BaseStream, header, 3, 0xA);
            // turnon(port.BaseStream, header, 3, 0xF);

            //writepacket(port.BaseStream, header, rxmraw);
            //writepacket(port.BaseStream, header, rxmsfrb);

            //writepacket(port.BaseStream, header, rxmraw6h);
            //writepacket(port.BaseStream, header, rxmsfrb6h);

            //writepacket(port.BaseStream, header, rxmraw6m);
            //writepacket(port.BaseStream, header, rxmsfrb6m);

            //return;

            //turnon(port.BaseStream, header, 2, 0x10);
            //turnon(port.BaseStream, header, 2, 0x11);

            //testmsg.startaddr += 8;
            //testmsg.data = turnonbytes;
            //writepacket(port.BaseStream, header, testmsg);

/*
            
            System.Threading.Thread.Sleep(200);

            while (port.IsOpen)
            {

                while (port.BytesToRead > 0)
                {
                    byte data = (byte)port.ReadByte();

                     //Console.Write("{0,2:x}",data);

                    processbyte(data);
                }

            }

            port.Close();

           // Console.ReadLine();

            return;
            
*/
            // safeboot
            var buf = new byte[] { 0xB5, 0x62, 0x09, 0x07, 0x00, 0x00, 0x10, 0x39 };
            buf = new byte[] {0xB5, 0x62, 0x09, 0x07, 0x01, 0x00, 0x01, 0x12, 0x4D};

            //port.Write(buf, 0, buf.Length);

            //port.Close();
            //Thread.Sleep(1000);
            //port.Open();

            // dump rom/memory

            req = new uploadreq();
            req_sec = new uploadreq_sec();
            req_sec.clas = 0x9;
            req_sec.subclass = 0x20;
            req_sec.length = 0x2C;
            req_sec.startaddr = 0x800001;
            req_sec.datasize = 0x10;
            req.flags = 0;

            var deadline = DateTime.MinValue;
            uint lastaddr = 0;

            while (port.IsOpen)
            {
                // determine when to send a new/next request
                if (deadline < DateTime.Now || lastaddr != req.startaddr)
                {
                    /*
                    ??:??:?? 0000  B5 62 09 20 2C 00 9C 59 C5 22 EC 34 1A 1A 30 CC µb. ,..YÅ"ì4..0Ì
                              0010  B1 FB 69 CB AD 9A 41 83 6E DD 27 E4 FB A6 8C 71  ±ûiË­.A.nÝ'äû¦.q
                              0020  E3 AB 8A A4 0D 20 FC 7F 08 00 04 00 00 00 00 00  ã«.¤. ü.........
                              0030  00 00 D0 44
                     */
                    byte[] data = new byte[44+6+2];
                    byte[] data_out = new byte[32];
                    //byte[] data_packet = new byte[12];
                    byte[] data_packet = { 0xFC, 0x7F, 0x08, 0x00, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
                    byte[] data_seed = new byte[32];
                    var all = new byte[data.Length];
                    SHA256 sha = SHA256.Create();
                    data_seed = sha.ComputeHash(data_packet);
                    data_out = sha256(data_seed, data_packet);

                    for (var a = 0; a < data_out.Length; a++)
                    {
                        //Console.Write(" " + data_out[a].ToString("X2"));
                    }
                    //Console.WriteLine();
                    //Console.WriteLine("{0,2:x}", data_out.Length);
                    //Console.Write("{0,2:x}", lastaddr);


                    var val1 = 0x1A1A34EC22C5599C;
                    var val2 = 0x9AADCB69FBB1CC30;
                    var val3 = 0xA6FBE427DD6E8341;
                    var val4 = 0x200DA48AABE3718C;
                    data[0] = 0xB5;
                    data[1] = 0x62;
                    data[2] = 0x09;
                    data[3] = 0x20;
                    data[4] = 0x2C;
                    data[5] = 0x00;

                    req_sec.startaddr = 0x87FF0;

                    // 0x87FFC;
                    /*
                    data[8 * 4 + 6] = 0xF0;
                    data[8 * 4 + 1 + 6] = 0x7F;
                    data[8 * 4 + 2 + 6] = 0x08;
                    */

                    //0x20 00 04 90
                    /*
                    data[8 * 4 + 6] = 0x90;
                    data[8 * 4 + 1 + 6] = 0x04;
                    data[8 * 4 + 2 + 6] = 0x00;
                    data[8 * 4 + 3 + 6] = 0x20;
                    */
                    //0x2003F4
                    data[8 * 4 + 6] = 0xF4;
                    data[8 * 4 + 1 + 6] = 0x03;
                    data[8 * 4 + 2 + 6] = 0x20;
                    data[8 * 4 + 3 + 6] = 0x00;
                    //0xEE3114
                    /*
                    data[8 * 4 + 6] = 0x14;
                    data[8 * 4 + 1 + 6] = 0x31;
                    data[8 * 4 + 2 + 6] = 0xEE;
                    data[8 * 4 + 3 + 6] = 0x00;
                    */
                    /*
                    data[8 * 4 + 6] = 0xF8;
                    data[8 * 4 + 1 + 6] = 0x7F;
                    data[8 * 4 + 2 + 6] = 0x08;
                    */
                    //data[9 * 4 + 6] = 0x10;
                    data[9 * 4 + 6] = 0x10;
                    //Array.Copy(BitConverter.GetBytes(val1), 0, data, 6, 8);
                    //Array.Copy(BitConverter.GetBytes(val2), 0, data, 8+6, 8);
                    data[10 * 4 + 6] = 0;

                    //Array.Copy(BitConverter.GetBytes(val3), 0, data, 16 + 6, 8);
                    //Array.Copy(BitConverter.GetBytes(val4), 0, data, 16 + 8 + 6, 8);


                    var datastruct = StaticUtils.StructureToByteArray(req_sec);
                    //var datastruct = StaticUtils.StructureToByteArray(req);

                    var checksum = ubx_checksum(datastruct, datastruct.Length);
                    //var checksum = ubx_checksum(data, data.Length - 2);
                    for (var a = 0; a < datastruct.Length; a++)
                    {
                        Console.Write(" " + datastruct[a].ToString("X2"));
                    }
                    Console.WriteLine();
                    // port.Write(header, 0, header.Length);
                    port.Write(datastruct, 0, datastruct.Length);
                     port.Write(checksum, 0, checksum.Length);

                    deadline = DateTime.Now.AddMilliseconds(1000);
                    lastaddr = req.startaddr;
                    //var all = new byte[header.Length + datastruct.Length + checksum.Length];
                    //var all = new byte[header.Length + data.Length + datastruct.Length + checksum.Length];

                    //Array.Copy(header, 0, all, 0, header.Length);
                    Array.Copy(data, 0, all, 0, data.Length);
                    //Array.Copy(datastruct, 0, all, 2, datastruct.Length);
                    Array.Copy(checksum, 0, all, all.Length - 2, checksum.Length);
                    //port.Write(all, 0, all.Length);

                    /*
                    for (var a = 0; a < all.Length; a++)
                    {
                        Console.Write(" " + all[a].ToString("X2"));
                    }
                    Console.WriteLine();
                    Console.WriteLine("{0,2:x}", all.Length);
                    //Console.Write("{0,2:x}", lastaddr);
                    */
                }

                Thread.Sleep(0);

                while (port.BytesToRead > 0)
                {
                    var data = (byte) port.ReadByte();

                     //Console.Write("{0,2:x}",data);
                    processbyte(data);
                }

            }
        }

        private static void writepacket(Stream port, byte[] header, object data)
        {
            var datastruct1 = StaticUtils.StructureToByteArray(data);

            var checksum1 = ubx_checksum(datastruct1, datastruct1.Length);

            port.Write(header, 0, header.Length);
            port.Write(datastruct1, 0, datastruct1.Length);
            port.Write(checksum1, 0, checksum1.Length);

            var all = new byte[header.Length + datastruct1.Length + checksum1.Length];

            Array.Copy(header, 0, all, 0, header.Length);
            Array.Copy(datastruct1, 0, all, 2, datastruct1.Length);
            Array.Copy(checksum1, 0, all, all.Length - 2, checksum1.Length);

            for (var a = 0; a < all.Length; a++)
            {
                Console.Write(" " + all[a].ToString("X"));
            }
            Console.WriteLine();
        }

        private static void processbyte(byte data)
        {
            switch (UBX_step) //Normally we start from zero. This is a state machine
            {
                case 0:
                    if (data == 0xB5) // UBX sync char 1
                        UBX_step++; //OH first data packet is correct, so jump to the next step
                    break;
                case 1:
                    if (data == 0x62) // UBX sync char 2
                        UBX_step++; //ooh! The second data packet is correct, jump to the step 2
                    else
                        UBX_step = 0; //Nop, is not correct so restart to step zero and try again.     
                    break;
                case 2:
                    UBX_class = data;
                    ubx_checksum(UBX_class);
                    UBX_step++;
                    break;
                case 3:
                    UBX_id = data;
                    ubx_checksum(UBX_id);
                    UBX_step++;
                    break;
                case 4:
                    UBX_payload_length_hi = data;
                    ubx_checksum(UBX_payload_length_hi);
                    UBX_step++;
                    // We check if the payload lenght is valid...
                    if (UBX_payload_length_hi >= UBX_MAXPAYLOAD)
                    {
                        UBX_step = 0; //Bad data, so restart to step zero and try again.     
                        ck_a = 0;
                        ck_b = 0;
                    }
                    break;
                case 5:
                    UBX_payload_length_lo = data;
                    ubx_checksum(UBX_payload_length_lo);
                    UBX_step++;
                    UBX_payload_counter = 0;
                    break;
                case 6: // Payload data read...
                    if (UBX_payload_counter < UBX_payload_length_hi)
                        // We stay in this state until we reach the payload_length
                    {
                        UBX_buffer[UBX_payload_counter] = data;
                        ubx_checksum(data);
                        UBX_payload_counter++;
                        if (UBX_payload_counter == UBX_payload_length_hi)
                            UBX_step++;
                    }
                    break;
                case 7:
                    UBX_ck_a = data; // First checksum byte
                    UBX_step++;
                    break;
                case 8:
                    UBX_ck_b = data; // Second checksum byte

                    // We end the GPS read...
                    if ((ck_a == UBX_ck_a) && (ck_b == UBX_ck_b))
                    {
                        // Verify the received checksum with the generated checksum.. 
                        // Parse the new GPS packet


                        if (UBX_class == 0x9 && UBX_id == 0x20)
                        {
                            //var resp = UBX_buffer.ByteArrayToStructure<uploadresp>(0);
                            var resp = UBX_buffer.ByteArrayToStructure<uploadresp_9_20_D>(0);
                            for (var a = 0; a < UBX_buffer.Length; a++)
                            {
                                //Console.Write(" " + UBX_buffer[a].ToString("X2"));
                            }
                            Console.WriteLine();
                            Console.Write("0x{0:X8} ", resp.startaddr);
                            Console.Write("0x{0:X2} -> ", resp.datasize);
                            Console.Write("0x{0:X8} ", resp.dat0);
                            Console.Write("0x{0:X8} ", resp.dat1);
                            Console.Write("0x{0:X8} ", resp.dat2);
                            Console.WriteLine("0x{0:X8}", resp.dat3);

                            // bw.Seek((int) resp.startaddr, SeekOrigin.Begin);
                            // bw.Write(resp.data, 0, (int)resp.datasize);
                        }
                        else
                        {
                            Console.WriteLine(DateTime.Now + "we have a packet 0x" + UBX_class.ToString("X") + " 0x" +
                                              UBX_id.ToString("X") + " " + UBX_payload_counter);
                        }
                    }
                    // Variable initialization
                    UBX_step = 0;
                    ck_a = 0;
                    ck_b = 0;

                    break;
            }
        }

        void temp0920_msg1()
        {
            byte[] data = new byte[44];
            /*
            ??:??:??  0000  B5 62 09 02 0C 00 FC 7F 08 00 04 00 00 00 00 00  µb....ü.........
                      0010  00 00 9E 0B                                      .....

            ??:??:??  0000  B5 62 09 20 2C 00 9C 59 C5 22 EC 34 1A 1A 30 CC  µb. ,..YÅ"ì4..0Ì
                      0010  B1 FB 69 CB AD 9A 41 83 6E DD 27 E4 FB A6 8C 71  ±ûiË­.A.nÝ'äû¦.q
                      0020  E3 AB 8A A4 0D 20 FC 7F 08 00 04 00 00 00 00 00  ã«.¤. ü.........
                      0030  00 00 D0 44  
             */
            var val1 = 0x1A1A34EC22C5599C;
            var val2 = 0x9AADCB69FBB1CC30;
             var val3 = 0xA6FBE427DD6E8341;
             var val4 = 0x200DA48AABE3718C;

            //data[8 * 4] = 0x87FFC;
            data[9*4] = 4;
            Array.Copy(BitConverter.GetBytes(val1), 0, data, 0, 8);
            Array.Copy(BitConverter.GetBytes(val2), 0, data, 8, 8);
            data[10*4] = 0;

            Array.Copy(BitConverter.GetBytes(val3), 0, data, 16, 8);
            Array.Copy(BitConverter.GetBytes(val4), 0, data, 16+8, 8);
        }

        void temp0920_msg2()
        {
            /*
          
??:??:??  0000  B5 62 09 02 0C 00 00 00 80 00 30 00 00 00 00 00  µb........0.....
          0010  00 00 C7 D6                                      ..ÇÖ.
          
??:??:??  0000  B5 62 09 20 2C 00 44 CF 68 EE 1F 73 48 65 9C 33  µb. ,.DÏhî.sHe.3
          0010  28 A3 3B CC 6C F4 4D EC BF 57 81 D8 BB E1 CB E1  (£;ÌlôMì¿W.Ø»áËá
          0020  B8 21 6C 8B A9 B0 00 00 80 00 30 00 00 00 00 00  ¸!l.©°....0.....
          0030  00 00 C7 DC                                      ..ÇÜ.
             */
            /*
    *(_QWORD *)&v10 = 0x6548731FEE68CF44i64;
    *((_QWORD *)&v10 + 1) = 0xF46CCC3BA328339Ci64;
    *(_QWORD *)&v11 = 0xE1BBD88157BFEC4Di64;
    *((_QWORD *)&v11 + 1) = 0xB0A98B6C21B8E1CBi64;
            */

            // 800000
        }

        private static void ubx_checksum(byte ubx_data)
        {
            ck_a += ubx_data;
            ck_b += ck_a;
        }

        private static byte[] ubx_checksum(byte[] packet, int size, int offset = 2)
        {
            uint a = 0x00;
            uint b = 0x00;
            var i = offset;
            while (i < size)
            {
                a += packet[i++];
                b += a;
            }

            var ans = new byte[2];

            ans[0] = (byte) (a & 0xFF);
            ans[1] = (byte) (b & 0xFF);

            return ans;
        }

        public static byte[] package(byte cl, byte subclass, byte[] payload)
        {
            var data = new byte[2+2+2+2+payload.Length];
            data[0] = 0xb5;
            data[1] = 0x62;
            data[2] = cl;
            data[3] = subclass;
            data[4] = (byte)(payload.Length & 0xff);
            data[5] = (byte)((payload.Length >> 8) & 0xff);

            Array.ConstrainedCopy(payload, 0, data, 6, payload.Length);

            var checksum = ubx_checksum(data, data.Length-2);

            data[data.Length - 2] = checksum[0];
            data[data.Length - 1] = checksum[1];

            return data;
        }

        /// <summary>
        /// write to receiver
        /// </summary>
        /// <param name="startadd"></param>
        /// <param name="flags"></param>
        /// <param name="dataBytes"></param>
        /// <returns></returns>
        public static byte[] UPD_DOWNL(uint startadd,uint flags, byte[] dataBytes)
        {
            var data = new byte[4+4+dataBytes.Length];

            Array.ConstrainedCopy(BitConverter.GetBytes(startadd), 0, data, 0, 4);
            Array.ConstrainedCopy(BitConverter.GetBytes(flags), 0, data, 4, 4);
            Array.ConstrainedCopy(dataBytes, 0, data, 8, dataBytes.Length);

            return data;
        }

        /// <summary>
        /// receive from gps
        /// </summary>
        public static byte[] UPD_UPLOAD(uint startadd, uint datasize, uint flags)
        {
            var data = new byte[4 + 4 + 4];

            Array.ConstrainedCopy(BitConverter.GetBytes(startadd), 0, data, 0, 4);
            Array.ConstrainedCopy(BitConverter.GetBytes(datasize), 0, data, 4, 4);
            Array.ConstrainedCopy(BitConverter.GetBytes(flags), 0, data, 8, 4);

            return data;
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private struct uploadresp
        {
            public readonly uint startaddr;
            public readonly uint datasize;
            public readonly uint flags;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)] public readonly byte[] data;
        }

        private struct uploadresp_9_20
        {

            public readonly uint rez;
            public readonly uint rez1;
            public readonly uint rez2;
            public readonly uint rez3;
            public readonly uint rez4;
            public readonly uint rez5;
            public readonly uint rez6;
            public readonly uint rez7;
            public readonly uint startaddr;
            public readonly uint datasize;
            public readonly uint flags;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)] public readonly byte[] data;
        }

        private struct uploadresp_9_20_D
        {

            public readonly uint rez;
            public readonly uint rez1;
            public readonly uint rez2;
            public readonly uint rez3;
            public readonly uint rez4;
            public readonly uint rez5;
            public readonly uint rez6;
            public readonly uint rez7;
            public readonly uint startaddr;
            public readonly uint datasize;
            public readonly uint flags;
            public readonly uint dat0;
            public readonly uint dat1;
            public readonly uint dat2;
            public readonly uint dat3;
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private struct downloadreq
        {
            public byte clas;
            public byte subclass;
            public ushort length;
            public uint startaddr;
            public uint flags;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)] public byte[] data;
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private struct uploadreq
        {
            public byte clas;// = 9;
            public byte subclass;// = 2;
            public ushort length;
            public uint startaddr;
            public uint datasize;
            public uint flags;
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private struct uploadreq_sec
        {
            public byte clas;// = 9;
            public byte subclass;// = 0x20;
            public ushort length;
            public UInt64 val1;
            public UInt64 val2;
            public UInt64 val3;
            public UInt64 val4;
            public uint startaddr;
            public uint datasize;
            public uint flags;
        }
        /*
        v?-7
            "UPD-DOWNL" : (0x09, 0x01),

            "UPD-EXEC" : (0x09, 0x03),

            "UPD-MEMCPY" : (0x09, 0x04),

            "UPD-UPLOAD" : (0x09, 0x02)

         * 
         *v8 09 0b - set addr // B5 62 09 0B 05 00 00 00 80 00 01 9A 4D
         *   09 0c - data
         *   09 0d
         *   09 07 - safeboot
         *   09 0e - finish
         *   09 06 - identify
         *   09 21 - UPD-DOWNL
         *   09 08 - start addr ? // B5 62 09 08 04 00 00 00 80 00 95 98
         *   09 20 - UPD-UPLOAD
         */


        //delete flash fw
        /*
        ??:??:??  0000  B5 62 09 01 0C 00 00 00 80 00 00 01 00 00 55 42  µb............UB
                  0010  58 38 BE 50                                      X8¾P.
          
        ??:??:??  0000  B5 62 09 21 2C 00 55 70 C3 2B 19 A7 A5 C9 28 3B  µb.!,.UpÃ+.§¥É(;
                  0010  DD E8 D5 89 C4 91 8F E5 32 8B 20 24 1B 45 54 DB  ÝèÕ.Ä..å2. $.ETÛ
                  0020  30 0D 35 BB E1 1E 00 00 80 00 00 01 00 00 55 42  0.5»á.........UB
                  0030  58 38 EA 40                                      X8ê@.
         * 
        // dump something
        ??:??:??  0000  B5 62 09 02 0C 00 FC 7F 08 00 04 00 00 00 00 00  µb....ü.........
                  0010  00 00 9E 0B                                      .....
          
        ??:??:??  0000  B5 62 09 20 2C 00 9C 59 C5 22 EC 34 1A 1A 30 CC  µb. ,..YÅ"ì4..0Ì
                  0010  B1 FB 69 CB AD 9A 41 83 6E DD 27 E4 FB A6 8C 71  ±ûiË­.A.nÝ'äû¦.q
                  0020  E3 AB 8A A4 0D 20 FC 7F 08 00 04 00 00 00 00 00  ã«.¤. ü.........
                  0030  00 00 D0 44                                      ..ÐD.
         *B5 62 09 20 2C 00 9C 59 C5 22 EC 34 1A 1A 30 CC   B1 FB 69 CB AD 9A 41 83 6E DD 27 E4 FB A6 8C 71  E3 AB 8A A4 0D 20 FC 7F 08 00 04 00 00 00 00 00   00 00 D0 44

        ??:??:??  0000  B5 62 09 02 10 00 FC 7F 08 00 04 00 00 00 00 00  µb....ü.........
                  0010  00 00 99 F0 5A A1 26 54                          ...ðZ¡&T.
         */
    }
}
