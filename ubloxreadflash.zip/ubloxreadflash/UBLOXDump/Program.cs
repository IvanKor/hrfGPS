﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using MissionPlanner.Comms;

namespace UBLOXDump
{

    internal class Program
    {

        [DllImport("sha256.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
        //        [DllImport("sha256.dll")]
        static extern void sha256_starts(byte[] ctx);

        [DllImport("sha256.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
//        [DllImport("sha256.dll")]
        static extern void sha256_update(byte[] ctx, byte[] input, uint length);

        [DllImport("sha256.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
//        [DllImport("sha256.dll")]
        static extern void sha256_finish(byte[] ctx, byte[] digest);

        private static readonly BinaryWriter bw =
            new BinaryWriter(File.Open("bbramdata.bin", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.Read));
//        new BinaryWriter(File.Open("flashdata.bin", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.Read));
//        new BinaryWriter(File.Open("romdata.bin", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.Read));

        private static byte UBX_class;
        private static byte UBX_id;
        private static byte UBX_payload_length_hi;
        private static readonly int UBX_MAXPAYLOAD = 1000;
        private static byte ck_a;
        private static byte ck_b;
        private static byte UBX_payload_length_lo;
        private static byte UBX_ck_a;
        private static byte UBX_ck_b;
        private static int UBX_payload_counter;
        private static readonly byte[] UBX_buffer = new byte[256];

        private static int UBX_step;
        private static uint adr_now;
        private static uploadreq req;
        private static uploadreq_sec req_sec;
        private static downl_sec req_downl_sec;

        //http://gps.0xdc.ru/wiki/doku.php?id=u-blox_undocumented_messages

        public class msginfo
        {
            public string name;
            public byte cl;
            public byte id;

            public msginfo()
            {

            }

            public msginfo(string name, byte cl, byte id)
            {
                this.name = name;
                this.cl = cl;
                this.id = id;
            }
        }

        /* 
*v8 09 0b - set addr // B5 62 09 0B 05 00 00 00 80 00 01 9A 4D
*   09 0c - data
*   09 0d
*   09 07 - safeboot
*   09 0e - finish
*   09 06 - identify
*   09 21 - UPD-DOWNL
*   09 08 - start addr ? // B5 62 09 08 04 00 00 00 80 00 95 98
*   09 20 - UPD-UPLOAD
*/
        public static List<msginfo> msglist = new List<msginfo>()
        {
            new msginfo("ACK-ACK", 0x05, 0x01),
            new msginfo("ACK-NACK", 0x05, 0x00),
            new msginfo("AID-ALM", 0x0b, 0x30),
            new msginfo("AID-ALPSRV", 0XB, 0x32),
            new msginfo("AID-AOP", 0XB, 0x33),
            new msginfo("AID-DATA", 0x0b, 0x10),
            new msginfo("AID-EPH", 0x0b, 0x31),
            new msginfo("AID-HUI", 0x0b, 0x02),
            new msginfo("AID-INI", 0x0b, 0x01),
            new msginfo("AID-REQ", 0x0b, 0x00),
            new msginfo("CFG-ANT", 0x06, 0x13),
            new msginfo("CFG-CFG", 0x06, 0x09),
            new msginfo("CFG-DAT", 0x06, 0x06),
            new msginfo("CFG-EKF", 0x06, 0x12),
            new msginfo("CFG-FXN", 0x06, 0x0e),
            new msginfo("CFG-INF", 0x06, 0x02),
            new msginfo("CFG-LIC", 0x06, 0x80),
            new msginfo("CFG-MSG", 0x06, 0x01),
            new msginfo("CFG-NAV2", 0x06, 0x1a),
            new msginfo("CFG-NMEA", 0x06, 0x17),
            new msginfo("CFG-PRT", 0x06, 0x00),
            new msginfo("CFG-RATE", 0x06, 0x08),
            new msginfo("CFG-RST", 0x06, 0x04),
            new msginfo("CFG-PWR", 0x06, 0x57),
            new msginfo("CFG-RXM", 0x06, 0x11),
            new msginfo("CFG-SBAS", 0x06, 0x16),
            new msginfo("CFG-TM", 0x06, 0x10),
            new msginfo("CFG-TM2", 0x06, 0x19),
            new msginfo("CFG-TMODE", 0x06, 0x1d),
            new msginfo("CFG-TMODE3", 6, 0x71),
            new msginfo("CFG-TP", 0x06, 0x07),
            new msginfo("CFG-USB", 0x06, 0x1b),
            new msginfo("CFG-GEOFENCE", 0x06, 0x69),
            new msginfo("CFG-GNSS", 0x06, 0x3e),
            // “B5 62 06 41 0C 00 00 00 03 1F C5 90 E1 9F FF FF FE FF 45 79” enables  the  DC/DC  converter in internal OTP memory
            new msginfo("INF-DEBUG", 0x04, 0x04),
            new msginfo("INF-ERROR", 0x04, 0x00),
            new msginfo("INF-NOTICE", 0x04, 0x02),
            new msginfo("INF-TEST", 0x04, 0x03),
            new msginfo("INF-USER", 0x04, 0x07),
            new msginfo("INF-WARNING", 0x04, 0x01),
            new msginfo("LOG-INFO", 0X21, 8),
            new msginfo("MON-EXCEPT", 0x0a, 0x05),
            new msginfo("MON-HW", 0x0a, 0x09),
            new msginfo("MON-HW2", 0XA, 0XB),
            new msginfo("MON-IO", 0x0a, 0x02),
            new msginfo("MON-IPC", 0x0a, 0x03),
            new msginfo("MON-LLC", 0xa, 0xd),
            new msginfo("MON-MSGPP", 0x0a, 0x06),
            new msginfo("MON-RXBUF", 0x0a, 0x07),
            new msginfo("MON-SCHD", 0x0a, 0x01),
            new msginfo("MON-SPEC", 0x0a, 0x1d),
            new msginfo("MON-RXR", 0x0a, 0x21),
            new msginfo("MON-TXBUF", 0x0a, 0x08),
            new msginfo("MON-USB", 0x0a, 0x0a),
            new msginfo("MON-VER", 0x0a, 0x04),
            new msginfo("MON-PATCH", 0x0a, 0x27),
            new msginfo("NAV-AOPSTATUS", 0x01, 0X60),
            new msginfo("NAV-EOE", 0x01, 0X61),
            new msginfo("NAV-CLOCK", 0x01, 0x22),
            new msginfo("NAV-DGPS", 0x01, 0x31),
            new msginfo("NAV-DOP", 0x01, 0x04),
            new msginfo("NAV-EKFSTATUS", 0x01, 0x40),
            new msginfo("NAV-GEOFENCE", 0X1, 0X39),
            new msginfo("NAV-ODO", 0X1, 0X9),
            new msginfo("NAV-ORB", 0X1, 0X34),
            new msginfo("NAV-POSECEF", 0x01, 0x01),
            new msginfo("NAV-POSLLH", 0x01, 0x02),
            new msginfo("NAV-POSUTM", 0x01, 0x08),
            new msginfo("NAV-PVT", 0x01, 0x07),
            new msginfo("NAV-RELPOSNED", 0X1, 0X3C),
            new msginfo("NAV-SAT", 0X1, 0X35),
            new msginfo("NAV-SBAS", 0x01, 0x32),
            new msginfo("NAV-SOL", 0x01, 0x06),
            new msginfo("NAV-STATUS", 0x01, 0x03),
            new msginfo("NAV-SVIN", 0X1, 0X3B),
            new msginfo("NAV-SVINFO", 0x01, 0x30),
            new msginfo("NAV-TIMEBDS", 0X1, 0X24),
            new msginfo("NAV-TIMEGAL", 0X1, 0X25),
            new msginfo("NAV-TIMEGLO", 0X1, 0X23),
            new msginfo("NAV-TIMEGPS", 0x01, 0x20),
            new msginfo("NAV-TIMELS", 0X1, 0X26),
            new msginfo("NAV-TIMEUTC", 0x01, 0x21),
            new msginfo("NAV-VELECEF", 0x01, 0x11),
            new msginfo("NAV-VELNED", 0x01, 0x12),
            new msginfo("NMEA", 0xf0, 0),
            new msginfo("NMEA", 0xf0, 1),
            new msginfo("NMEA", 0xf0, 10),
            new msginfo("NMEA", 0xf0, 11),
            new msginfo("NMEA", 0xf0, 12),
            new msginfo("NMEA", 0xf0, 13),
            new msginfo("NMEA", 0xf0, 14),
            new msginfo("NMEA", 0xf0, 15),
            new msginfo("NMEA", 0xf0, 2),
            new msginfo("NMEA", 0xf0, 3),
            new msginfo("NMEA", 0xf0, 4),
            new msginfo("NMEA", 0xf0, 5),
            new msginfo("NMEA", 0xf0, 6),
            new msginfo("NMEA", 0xf0, 7),
            new msginfo("NMEA", 0xf0, 8),
            new msginfo("NMEA", 0xf0, 9),
            new msginfo("NMEA", 0xf0, 0x40),
            new msginfo("NMEA", 0xf0, 0x42),
            new msginfo("NMEA", 0xf0, 0x43),
            new msginfo("NMEA", 0xf0, 0x44),
            new msginfo("pubx00", 0xf1, 0),
            new msginfo("pubx01", 0xf1, 1),
            new msginfo("pubx03", 0xf1, 3),
            new msginfo("pubx04", 0xf1, 4),
            new msginfo("PUBX-RATE", 0xf1, 0x40),
            new msginfo("PUBX-CONFIG", 0xf1, 0x41),

            new msginfo("RTCM1005", 0XF5, 0x05),/**< Stationary RTK reference station ARP */
            new msginfo("RTCM1074", 0XF5, 0x4A),/**< GPS MSM4 */
            new msginfo("RTCM1077", 0XF5, 0X4D),/**< GPS MSM7 */
            new msginfo("RTCM1084", 0XF5, 0X54),/**< GLONASS MSM4 */
            new msginfo("RTCM1087", 0XF5, 0X57),/**< GLONASS MSM7 */
            new msginfo("RTCM1094", 0XF5, 0X5E),/**< GALILEO MSM4 */
            new msginfo("RTCM1097", 0XF5, 0X61),/**< GALILEO MSM7 */
            new msginfo("RTCM1124", 0XF5, 0X7C),/**< BeiDou MSM4 */
            new msginfo("RTCM1127", 0XF5, 0X7F),/**< BeiDou MSM7 */
            new msginfo("RTCM1230", 0XF5, 0XE6),/**< GLONASS code-phase biases */
            new msginfo("RTCM4072", 0XF5, 0xFE),/**< Reference station PVT (u-blox proprietary RTCM Message) - Used for moving baseline */

            new msginfo("MGA-GPS", 0x13, 0x00),
            new msginfo("MGA-GAL", 0x13, 0x02),
            new msginfo("MGA-BDS", 0x13, 0x03),
            new msginfo("MGA-QZSS-EPH", 0x13, 0x05),
            new msginfo("MGA-GPS-TIMEOFFSET", 0x13, 0x06),
            new msginfo("MGA-MGA-INI", 0x13, 0x40),
            new msginfo("MGA-DBD", 0x13, 0x80),
            new msginfo("MGA-ANO", 0x13, 0x20),
            new msginfo("MGA-FLASH", 0x13, 0x21),

            new msginfo("RXM-ALM", 0x02, 0x30),
            new msginfo("RXM-EPH", 0x02, 0x31),
            new msginfo("RXM-EPH", 0x02, 0x31),
            new msginfo("RXM-MEASX", 0x02, 0x14),
            new msginfo("RXM-POSREQ", 0x02, 0x40),
            new msginfo("RXM-RAW", 0x02, 0x10),
            new msginfo("RXM-RAWX", 0x02, 0x15),
            new msginfo("RXM-SFRB", 0x02, 0x11),
            new msginfo("RXM-SFRBX", 0x02, 0x13),
            new msginfo("RXM-SVSI", 0x02, 0x20),
            new msginfo("RXM-RLM", 0x02, 0x59),
            new msginfo("RXM-IMES", 0x02, 0x61),
            new msginfo("SEC-SIGN", 0X27, 1),
            new msginfo("SEC-UNIQID", 0X27, 3),
            new msginfo("TIM-SVIN", 0x0d, 0x04),
            new msginfo("TIM-TM", 0x0d, 0x02),
            new msginfo("TIM-TM2", 0x0d, 0x03),
            new msginfo("TIM-TP", 0x0d, 0x01),
            new msginfo("TIM-VRFY", 0x0d, 0x06),
            new msginfo("TRK-MEAS", 3, 0x10),
            new msginfo("TRK-SFRB", 3, 0x2),
            new msginfo("TRK-SFRBX", 3, 0xf),
            new msginfo("TRK-TRKD2", 3, 0x6),
            new msginfo("TRK-TRKD5", 3, 0x0a),
            new msginfo("UPD", 9, 0xff),
            new msginfo("UPD-csum", 9, 0xd),
            new msginfo("UPD-DOWNL", 0x09, 0x01),
            new msginfo("UPD-DOWNL-SEC", 0x09, 0x21),
            new msginfo("UPD-erase", 9, 0xb),
            new msginfo("UPD-EXEC", 0x09, 0x03),
            new msginfo("UPD-EXEC-SEC", 0x09, 0x22),
            new msginfo("UPD-FLDET", 9, 8),
            new msginfo("UPD-identify", 9, 6),
            new msginfo("UPD-MEMCPY", 0x09, 0x04),
            new msginfo("UPD-RBOOT", 9, 0xe), // EXIT
            new msginfo("UPD-SAFE", 9, 7), // ENTER
            new msginfo("UPD-SOS", 9, 0x14),
            new msginfo("UPD-UPLOAD", 0x09, 0x02),
            new msginfo("UPD-UPLOAD-SEC", 0x09, 0x20),
            new msginfo("UPD-write", 9, 0xc),

        };

        public static msginfo GetMsginfo(byte cl, byte id)
        {
            var list = msglist.Where(a => a.cl == cl && a.id == id);

            if (list.Count() == 0)
                return new msginfo("UNKNOWN", 0, 0);

            return list.First();
        }
        //63 F6 8C BA
        //BA8CF663
        //0x6D9BC8
        //0x86AF74
        //
        static byte[] sha256_sec(byte[] packet)
        {
            byte[] ctx = new byte[104] ; // 104 => sizeof(sha256_ctx)
            byte[] hash = new byte[32]; //  32 => 256-bit sha256
            var FixedHi = new byte[] { 0x63, 0x73, 0xD6, 0x62 };
            var FixedLo = new byte[] { 0x35, 0x53, 0xA1, 0x96 };

            sha256_starts(ctx);
            sha256_update(ctx, FixedHi, 4); // FIXED HI
            sha256_update(ctx, packet,(uint) packet.Length);
            sha256_update(ctx, FixedLo, 4); // FIXED LO
            sha256_finish(ctx, hash);

            return hash;

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="file">raw dump</param>
        /// <param name="outputfile">output</param>
        /// <param name="startoffset">Memory location</param>
        /// <param name="secondsoffset">Flash location</param>
        private static void ExtractPacketAddresses(string file, string outputfile, int startoffset,
            int secondsoffset = 0, bool m8 = false)
        {
            if (!File.Exists(file))
                return;

            TextWriter tw = new StreamWriter(outputfile);

            var br = new BinaryReader(File.OpenRead(file));

            // 0x1420 - 6m
            // 0x3e4c - 7n

            br.BaseStream.Seek(startoffset, SeekOrigin.Begin);

            var lowestoffset = uint.MaxValue;

            while (br.BaseStream.Position < (startoffset + 4000))
            {
                var posstart = br.BaseStream.Position;
                var addr = br.ReadUInt32();
                if (addr != 0)
                    lowestoffset = Math.Min(addr, lowestoffset);
                br.BaseStream.Seek(2, SeekOrigin.Current);
                var clas = br.ReadByte();
                var subclas = br.ReadByte();
                br.BaseStream.Seek(12, SeekOrigin.Current);

                var pos = br.BaseStream.Position;

                ulong ch = 0;

                if (br.BaseStream.Length > addr)
                {
                    br.BaseStream.Seek(addr, SeekOrigin.Begin);

                    ch = br.ReadUInt64();

                    br.BaseStream.Seek(pos, SeekOrigin.Begin);
                }

                var type = GetMsginfo(clas, subclas);

                var name = type.name;

                tw.WriteLine(posstart.ToString("X") + "\t" + clas.ToString("X") + "\t" + subclas.ToString("X") + "\t" +
                             addr.ToString("X") + "\t" + ch.ToString("X") + "\t" + name);
            }

            //
            while (br.BaseStream.Position < (startoffset + 2000 + 320))
            {
                var addr = br.ReadUInt32();
                tw.WriteLine(addr.ToString("X"));
            }

            tw.WriteLine("Message in FW");

            //second
            if (secondsoffset > 0)
            {
                br.BaseStream.Seek(secondsoffset, SeekOrigin.Begin);

                try
                {
                    while (br.BaseStream.Position < (secondsoffset + 0x928))
                    {
                        var posstart = br.BaseStream.Position;

                        var clas = br.ReadByte();
                        var subclas = br.ReadByte();
                        var zero = br.ReadByte();
                        var priorite = br.ReadByte();

                        //br.BaseStream.Seek(2, SeekOrigin.Current);

                        var addr = br.ReadUInt32();

                        if (!m8)
                            br.BaseStream.Seek(4, SeekOrigin.Current);

                        if (clas == 0 && subclas == 0)
                            continue;

                        var type = GetMsginfo(clas, subclas);

                        var name = type.name;

                        tw.WriteLine(posstart.ToString("X") + "\t" + clas.ToString("X") + "\t" + subclas.ToString("X") +
                                     "\t" + zero.ToString("X") + "\t" + priorite.ToString("X") +
                                     "\t" + addr.ToString("X") + "\t" + name);
                    }
                }
                catch
                {
                }
            }

            tw.Close();

            br.Close();
        }
        private static void ExtractPacketAddresses8N(string file, string outputfile, int startoffset,
            int secondsoffset = 0, bool m8 = false)
        {
            if (!File.Exists(file))
                return;

            TextWriter tw = new StreamWriter(outputfile);

            var br = new BinaryReader(File.OpenRead(file));

            // 0x1420 - 6m
            // 0x3e4c - 7n

            br.BaseStream.Seek(startoffset, SeekOrigin.Begin);

            var lowestoffset = uint.MaxValue;

            while (br.BaseStream.Position < (startoffset + 4000))
            {
                var posstart = br.BaseStream.Position;
                var addr = br.ReadUInt32();
                if (addr != 0)
                    lowestoffset = Math.Min(addr, lowestoffset);
                br.BaseStream.Seek(2, SeekOrigin.Current);
                var clas = br.ReadByte();
                var subclas = br.ReadByte();
                br.BaseStream.Seek(12, SeekOrigin.Current);

                var pos = br.BaseStream.Position;

                ulong ch = 0;

                if (br.BaseStream.Length > addr)
                {
                    br.BaseStream.Seek(addr, SeekOrigin.Begin);

                    ch = br.ReadUInt64();

                    br.BaseStream.Seek(pos, SeekOrigin.Begin);
                }

                var type = GetMsginfo(clas, subclas);

                var name = type.name;

                tw.WriteLine(posstart.ToString("X") + "\t" + clas.ToString("X") + "\t" + subclas.ToString("X") + "\t" +
                             addr.ToString("X") + "\t" + ch.ToString("X") + "\t" + name);
            }

            //
            while (br.BaseStream.Position < (startoffset + 2000 + 320))
            {
                var addr = br.ReadUInt32();
                tw.WriteLine(addr.ToString("X"));
            }

            tw.WriteLine("Message in FW");

            //second
            if (secondsoffset > 0)
            {
                br.BaseStream.Seek(secondsoffset, SeekOrigin.Begin);

                try
                {
                    while (br.BaseStream.Position < (secondsoffset + 0x928 + 336))
                    {
                        var posstart = br.BaseStream.Position;

                        var clas = br.ReadByte();
                        var subclas = br.ReadByte();
                        var zero = br.ReadByte();
                        var priorite = br.ReadByte();

                        //br.BaseStream.Seek(2, SeekOrigin.Current);

                        var addr = br.ReadUInt32();

                        if (!m8)
                            br.BaseStream.Seek(4, SeekOrigin.Current);

                        if (clas == 0 && subclas == 0)
                            continue;

                        var type = GetMsginfo(clas, subclas);

                        var name = type.name;

                        tw.WriteLine(posstart.ToString("X") + "\t" + clas.ToString("X") + "\t" + subclas.ToString("X") +
                                     "\t" + zero.ToString("X") + "\t" + priorite.ToString("X") +
                                     "\t" + addr.ToString("X") + "\t" + name);
                    }
                }
                catch
                {
                }
            }

            tw.Close();

            br.Close();
        }

        private static void ExtractPacketAddresses8T(string file, string outputfile, int startoffset,
            int secondsoffset = 0, bool m8 = false)
        {
            if (!File.Exists(file))
                return;

            TextWriter tw = new StreamWriter(outputfile);

            var br = new BinaryReader(File.OpenRead(file));

            // 0x1420 - 6m
            // 0x3e4c - 7n

            br.BaseStream.Seek(startoffset, SeekOrigin.Begin);

            var lowestoffset = uint.MaxValue;

            while (br.BaseStream.Position < (startoffset + 4000))
            {
                var posstart = br.BaseStream.Position;
                var addr = br.ReadUInt32();
                if (addr != 0)
                    lowestoffset = Math.Min(addr, lowestoffset);
                br.BaseStream.Seek(2, SeekOrigin.Current);
                var clas = br.ReadByte();
                var subclas = br.ReadByte();
                br.BaseStream.Seek(12, SeekOrigin.Current);

                var pos = br.BaseStream.Position;

                ulong ch = 0;

                if (br.BaseStream.Length > addr)
                {
                    br.BaseStream.Seek(addr, SeekOrigin.Begin);

                    ch = br.ReadUInt64();

                    br.BaseStream.Seek(pos, SeekOrigin.Begin);
                }

                var type = GetMsginfo(clas, subclas);

                var name = type.name;

                tw.WriteLine(posstart.ToString("X") + "\t" + clas.ToString("X") + "\t" + subclas.ToString("X") + "\t" +
                             addr.ToString("X") + "\t" + ch.ToString("X") + "\t" + name);
            }

            //
            while (br.BaseStream.Position < (startoffset + 2000 + 320))
            {
                var addr = br.ReadUInt32();
                tw.WriteLine(addr.ToString("X"));
            }

            tw.WriteLine("Message in FW");

            //second
            if (secondsoffset > 0)
            {
                br.BaseStream.Seek(secondsoffset, SeekOrigin.Begin);

                try
                {
                    while (br.BaseStream.Position < (secondsoffset + 0x928 + 368))
                    {
                        var posstart = br.BaseStream.Position;

                        var clas = br.ReadByte();
                        var subclas = br.ReadByte();
                        var zero = br.ReadByte();
                        var priorite = br.ReadByte();

                        //br.BaseStream.Seek(2, SeekOrigin.Current);

                        var addr = br.ReadUInt32();

                        if (!m8)
                            br.BaseStream.Seek(4, SeekOrigin.Current);

                        if (clas == 0 && subclas == 0)
                            continue;

                        var type = GetMsginfo(clas, subclas);

                        var name = type.name;

                        tw.WriteLine(posstart.ToString("X") + "\t" + clas.ToString("X") + "\t" + subclas.ToString("X") +
                                     "\t" + zero.ToString("X") + "\t" + priorite.ToString("X") +
                                     "\t" + addr.ToString("X") + "\t" + name);
                    }
                }
                catch
                {
                }
            }

            tw.Close();

            br.Close();
        }



        private static void ExtractPacketAddresses8PREF(string file, string outputfile, int startoffset,
            int secondsoffset = 0, bool m8 = false)
        {
            if (!File.Exists(file))
                return;

            TextWriter tw = new StreamWriter(outputfile);

            var br = new BinaryReader(File.OpenRead(file));

            // 0x1420 - 6m
            // 0x3e4c - 7n

            br.BaseStream.Seek(startoffset, SeekOrigin.Begin);

            var lowestoffset = uint.MaxValue;

            while (br.BaseStream.Position < (startoffset + 4000))
            {
                var posstart = br.BaseStream.Position;
                var addr = br.ReadUInt32();
                if (addr != 0)
                    lowestoffset = Math.Min(addr, lowestoffset);
                br.BaseStream.Seek(2, SeekOrigin.Current);
                var clas = br.ReadByte();
                var subclas = br.ReadByte();
                br.BaseStream.Seek(12, SeekOrigin.Current);

                var pos = br.BaseStream.Position;

                ulong ch = 0;

                if (br.BaseStream.Length > addr)
                {
                    br.BaseStream.Seek(addr, SeekOrigin.Begin);

                    ch = br.ReadUInt64();

                    br.BaseStream.Seek(pos, SeekOrigin.Begin);
                }

                var type = GetMsginfo(clas, subclas);

                var name = type.name;

                tw.WriteLine(posstart.ToString("X") + "\t" + clas.ToString("X") + "\t" + subclas.ToString("X") + "\t" +
                             addr.ToString("X") + "\t" + ch.ToString("X") + "\t" + name);
            }

            //
            while (br.BaseStream.Position < (startoffset + 2000 + 320))
            {
                var addr = br.ReadUInt32();
                tw.WriteLine(addr.ToString("X"));
            }

            tw.WriteLine("Message in FW");

            //second
            if (secondsoffset > 0)
            {
                br.BaseStream.Seek(secondsoffset, SeekOrigin.Begin);

                try
                {
                    while (br.BaseStream.Position < (secondsoffset + 0x928 + 368 + 760))
                    {
                        var posstart = br.BaseStream.Position;

                        var clas = br.ReadByte();
                        var subclas = br.ReadByte();
                        var zero = br.ReadByte();
                        var priorite = br.ReadByte();

                        //br.BaseStream.Seek(2, SeekOrigin.Current);

                        var addr = br.ReadUInt32();

                        if (!m8)
                            br.BaseStream.Seek(4, SeekOrigin.Current);

                        if (clas == 0 && subclas == 0)
                            continue;

                        var type = GetMsginfo(clas, subclas);

                        var name = type.name;

                        tw.WriteLine(posstart.ToString("X") + "\t" + clas.ToString("X") + "\t" + subclas.ToString("X") +
                                     "\t" + zero.ToString("X") + "\t" + priorite.ToString("X") +
                                     "\t" + addr.ToString("X") + "\t" + name);
                    }
                }
                catch
                {
                }
            }

            tw.Close();

            br.Close();
        }


        private const string usageText = "Usage: bbramdataread com2 115200";
 
        private static void Main(string[] args)
        {
            string COM_POTR;
            Int32 BaudCom;

            if (args.Length < 2)
            {
                Console.WriteLine(usageText);
                Console.ReadKey();
                return ;
            }
            COM_POTR = args[0];
            BaudCom = Convert.ToInt32( args[1]);
/*
//            Console.WriteLine(args[0]);
//            Console.WriteLine(args[1]);
            try
            {
                // Attempt to open output file.
                using (var writer = new StreamWriter(args[1]))
                {
                    using (var reader = new StreamReader(args[0]))
                    {
                        // Redirect standard output from the console to the output file.
                        Console.SetOut(writer);
                        // Redirect standard input from the console to the input file.
                        Console.SetIn(reader);
                        string line;
                        while ((line = Console.ReadLine()) != null)
                        {
                            string newLine = line.Replace(("").PadRight(tabSize, ' '), "\t");
                            Console.WriteLine(newLine);
                        }
                    }
                }
            }
            catch (IOException e)
            {
                TextWriter errorWriter = Console.Error;
                errorWriter.WriteLine(e.Message);
                errorWriter.WriteLine(usageText);
                return;
            }

            // Recover the standard output stream so that a 
            // completion message can be displayed.
            var standardOutput = new StreamWriter(Console.OpenStandardOutput());
            standardOutput.AutoFlush = true;
            Console.SetOut(standardOutput);
            Console.WriteLine($"INSERTTABS has completed the processing of {args[0]}.");
            return ;
*/



            ExtractPacketAddresses("UBLOX_M8_201.89cc4f1cd4312a0ac1b56c790f7c1622.bin",
                "Addr8_201.txt", 0, 0x739e8);
            ExtractPacketAddresses("FW101_EXT_TITLIS.42ec35ce38d201fd723f2c8b49b6a537.bin",
                "Addr7.txt", 0, 0x62f0c);
            ExtractPacketAddresses("EXT_G60_LEA-6H.bin",
                "Addr6.txt", 0, 0x546DC);
            ExtractPacketAddresses8N("UBX_M8_301_SPG.911f2b77b649eb90f4be14ce56717b49.bin",
                "Addr8N_301.txt", 0, 0x7904c, true);
            ExtractPacketAddresses8N("301ROM.bin",
                "Addr8N_301_ROM.txt", 0, 0x84B0C, true);
            ExtractPacketAddresses8T("M8T_3.01.bin",
                "Addr8T_301.txt", 0, 0x7A998, true);
            ExtractPacketAddresses8PREF("301_140_REFERENCE.bin",
                "Addr8PREF_301.txt", 0, 0x73990, true);



            //return;

            msginfo PrintMSG()
            {
                var packet = new byte[] { 0xB5, 0x62, 0x06, 0x3E, 0x00, 0x00 };

                for (var a = 0; a < packet.Length; a++)
                {
                    Console.Write(" " + packet[a].ToString("X2"));
                }
                var checksum = ubx_checksum(packet, packet.Length);
                for (var a = 0; a < checksum.Length; a++)
                {
                    Console.Write(" " + checksum[a].ToString("X2"));
                }
                Console.WriteLine();

                return null;
            }

            msginfo PrintWriteWordSEC(uint startaddr, uint data)
            {
                byte[] data_hash = new byte[32];
                byte[] data_packet = new byte[12];
                req_downl_sec = new downl_sec();
                req_downl_sec.head1 = 0xB5;
                req_downl_sec.head2 = 0x62;
                req_downl_sec.clas = 0x9;
                req_downl_sec.subclass = 0x21;
                req_downl_sec.length = 0x2C;
                req_downl_sec.startaddr = startaddr;
                req_downl_sec.flags = 0; //0xE008 !!!
                req_downl_sec.data = data;
                var datastruct = StaticUtils.StructureToByteArray(req_downl_sec);
                Array.Copy(datastruct, 38, data_packet, 0, 12);
                data_hash = sha256_sec(data_packet);
                Array.Copy(data_hash, 0, datastruct, 6, 32);
                var checksum = ubx_checksum(datastruct, datastruct.Length);
                //port.Write(datastruct, 0, datastruct.Length);
                //port.Write(checksum, 0, checksum.Length);
                for (var a = 0; a < datastruct.Length; a++)
                {
                    Console.Write(" " + datastruct[a].ToString("X2"));
                }
                for (var a = 0; a < checksum.Length; a++)
                {
                    Console.Write(" " + checksum[a].ToString("X2"));
                }
                Console.WriteLine();

                return null;
            }

            msginfo PrintMSG_RF_CFG()
            {
                //var packet = new byte[] { 0xB5, 0x62, 0x06, 0x49, 0x18, 0x00, 0x02, 0x00, 0x00,
                //                         0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00,
                //                         0x00, 0x00, 0x00, 0x00, 0x38, 0x00, 0x0F, 0x00, 0x38, 0x00, 0x0F, 0x01 };
                var packet = new byte[] { 0xB5, 0x62, 0x06, 0x49, 0x18, 0x00, 0x02, 0x00, 0x00,
                                          0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00,
                                          0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01 };

                for (var a = 0; a < packet.Length; a++)
                {
                    Console.Write(" " + packet[a].ToString("X2"));
                }
                var checksum = ubx_checksum(packet, packet.Length);
                for (var a = 0; a < checksum.Length; a++)
                {
                    Console.Write(" " + checksum[a].ToString("X2"));
                }
                Console.WriteLine();

                return null;
            }
            // B5 62 0A 0D 00 00 17 4F read LLC
            //B5 62 0A 2B 00 00 35 A9
            //B5 62 0C 10 00 00 1C 60
            //B5 62 0C 31 00 00 3D C3
            //B5 62 0C 34 00 00 40 CC
            //B5 62 0A 26 00 00 30 9A //!!! out copy RF-mem for monitor
            //B5 62 0C 34 00 00 40 CC //work calc SEC
            //B5 62 06 41 00 00 47 DB //E_Fuse MEM read & write
            /*

            
B5 62 06 41 0C 00 
00 00 03 1F 
90 47 4F B1 
FF FF EA FF 
33 98
B5 62 06 41 0C 00 
00 00 03 1F
C5 90 E1 9F
FF FF FE FF 
45 79
08:32:30  0000  B5 62 06 41 00 00 47 DB µb.A..GÛ.
08:32:30  0000  B5 62 06 41 80 00 4C B4 57 5D D2 FF FF FF FF FF  µb.A..L´W]Òÿÿÿÿÿ
          0010  EF EB FF FF FF FF 92 EE FF FF FF FF FF FF FF FF ïëÿÿÿÿ.îÿÿÿÿÿÿÿÿ
          0020  FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF  ÿÿÿÿÿÿÿÿÿÿÿÿÿÿÿÿ
          0030  FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF  ÿÿÿÿÿÿÿÿÿÿÿÿÿÿÿÿ
          0040  FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF  ÿÿÿÿÿÿÿÿÿÿÿÿÿÿÿÿ
          0050  FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF  ÿÿÿÿÿÿÿÿÿÿÿÿÿÿÿÿ
          0060  FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF  ÿÿÿÿÿÿÿÿÿÿÿÿÿÿÿÿ
          0070  FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF  ÿÿÿÿÿÿÿÿÿÿÿÿÿÿÿÿ
          0080  FF FF FF FF FF FF 30 3D                          ÿÿÿÿÿÿ0 =.

B5 62 06 41 0C 00 00 00 03 1F 47 F2 D7 AD FF FF FC FF 2B 3D

06 41 - class/id
80 00 - len
3E AE 07 3F EB FF FF FF FF FF EF FB FE FF FC FF
95 A8 06 55 24 00 00 06 00 00 F9 04 00 00 C8 32
00 00 00 00 00 00 A8 61 00 00 D0 07 00 00 E8 03
00 00 74 40 00 00 10 0E E8 03 82 9C 8C A4 04 00
F1 A0 F7 F7 00 2C 01 D0 C7 F8 30 51 0C 38 00 EB
08 05 0E F1 02 0E F7 46 FF FF FF FF FF FF FF FF
FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF
FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF

0x3E, 0xAE, 0x07, 0x3F, 0xEB, 0xFF, 0xFF, 0xFF, 0x07, 0xF8, 0xEF, 0xFB, 0xFE, 0xFF, 0xFC, 0xFF,
0x95, 0xA8, 0x06, 0x55, 0x24, 0x00, 0x00, 0x06, 0x00, 0x00, 0xF9, 0x04, 0x00, 0x00, 0xC8, 0x32,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xA8, 0x61, 0x00, 0x00, 0xD0, 0x07, 0x00, 0x00, 0xE8, 0x03,
0x00, 0x00, 0x74, 0x40, 0x00, 0x00, 0x10, 0x0E, 0xE8, 0x03, 0x82, 0x9C, 0x8C, 0xA4, 0x04, 0x00,
0xF1, 0xA0, 0xF7, 0xF7, 0x00, 0x2C, 0x01, 0xD0, 0xC7, 0xF8, 0x30, 0x51, 0x0C, 0x38, 0x00, 0xEB,
0x08, 0x05, 0x0E, 0xF1, 0x02, 0x0E, 0xF7, 0x46, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,


            */
            //B5 62 06 49 00 00 4F F3 //UNKNOWN_6_49_RF_CONFIG
            //B5 62 06 49 18 00 02 00 00 00 00 10 00 00 00 10 00 00 00 00 00 00 38 00 0F 00 38 00 0F 01 18 34 //UNKNOWN_6_49_RF_CONFIG
            //B5 62 06 49 18 00 02 00 00 00 00 10 00 00 00 10 00 00 00 00 00 00 38 00 0F 00 00 00 00 00 D0 35
            //B5 62 06 49 18 00 02 00 00 00 00 10 00 00 00 10 00 00 00 00 00 00 38 00 0F 00 77 00 00 00 47 11
            //B5 62 06 49 18 00 02 00 00 00 00 10 00 00 00 10 00 00 00 00 00 00 38 00 0F 00 FF 0F FF 03 E0 5F
            //PrintMSG();
            //return;
            //PrintMSG_RF_CFG();


            //PrintWriteWordSEC(0x20000030, 0x7FFFFFFF);//its OK IF write this & REBOOT
            //PrintWriteWordSEC(0x20000034, 0xFFFFFFED);//its OK IF write this & REBOOT
            //PrintWriteWordSEC(0x2000003C, 0xFFFFFF9E);//its OK IF write this & REBOOT
            //PrintWriteWordSEC(0x20000040, 0xFFFFFF69);//its OK IF write this & REBOOT

            //PrintWriteWordSEC(0x2000004c, 0x0);//fix USB RAM_20000000_8PREF_301


            //return;

            /*
            Console.WriteLine("Составить программу вывода на экран в одну строку трех любых чисел с двумя пробелами между ними.");
            int number1, number2, number3;
            number1 = Convert.ToInt32(Console.ReadLine());
            number2 = Convert.ToInt32(Console.ReadLine());
            number3 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Число 1: " + number1 + ", Число 2: " + number2 + ", Число 3: " + number3);
            */
            ICommsSerial port;
            port = new MissionPlanner.Comms.SerialPort();
            Console.WriteLine("Open SerialPort:" + COM_POTR + " baudRate="+ BaudCom);

            //port.PortName = "com9";
            port.PortName = COM_POTR;
            //port.PortName = Console.ReadLine();
            //port.BaudRate = 9600;
            port.BaudRate = BaudCom;
            port.ReadBufferSize = 1024*1024;
            try
            {
                port.Open();
            }
            catch (IOException e)
            {
                TextWriter errorWriter = Console.Error;
                errorWriter.WriteLine(e.Message);
                errorWriter.WriteLine(usageText);
                Console.ReadKey();
                return;
            }

            //B5 62 09 0D 08 00 04 00 80 00 94 56 05 00 91 C7
            //B5 62 09 0D 08 00 20 10 80 00 9F 9C 07 00 91 C7 79C9F 1020 80 00 04

            msginfo WriteEFuseBBRAM()
            {
                byte[] data_hash = new byte[32];
                var org_packet_eFuse = new byte[]
                                    {0xB5, 0x62, 0x09, 0x21, 0x84+0x08+0x20, 0x00, 0x00, 0x00, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00,
                                    0x4C, 0xB4, 0x57, 0x5D, 0xD2, 0xFF, 0xFF, 0xFF, 0x07, 0xF8, 0xEF, 0xEB, 0xFF, 0xFF, 0xFF, 0xFF,
                                    0x92, 0xEE, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
                                    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
                                    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
                                    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
                                    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
                                    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
                                    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
                                    0xFF, 0xFF, 0xFF, 0xFF};
                var packet_eFuse_REF_M8T = new byte[]
                //LLC=FFFFFFFF-FFFFFFED-FFFFFFFF-FFFFF79E-FFFFFF69
                                    {0xB5, 0x62, 0x09, 0x21, 0xAC, 0x00, 0x00, 0x00, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00,
                                    0x4C, 0xB4, 0x57, 0x5D, 0xD2, 0xFF, 0xFF, 0xFF, 0x07, 0xF8, 0xEF, 0xFB, 0xFF, 0x76, 0xEF, 0xFF,
                                    0x92, 0xEE, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
                                    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
                                    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
                                    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
                                    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
                                    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
                                    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
                                    0xFF, 0xFF, 0xFF, 0xFF};


                var packet_eFuse_OK = new byte[]
                                    {0xB5, 0x62, 0x09, 0x21, 0x84+0x08+0x20, 0x00, 0x00, 0x00, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00,
                                    0x4C, 0xB4, 0x57, 0x5D, 0xD2, 0xFF, 0xFF, 0xFF, 0x07, 0xF8, 0xEF, 0xFB, 0xFF, 0x76, 0xEF, 0xFF,
                                    0x92, 0xEE, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
                                    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
                                    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
                                    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
                                    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
                                    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
                                    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
                                    0xFF, 0xFF, 0xFF, 0xFF};
                // FBEFF807 FBAFF807
                var packet_eFuse_clark = new byte[]
                                    {0xB5, 0x62, 0x09, 0x21, 0x84+0x08+0x20, 0x00, 0x00, 0x00, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00,
                                    0x46, 0x15, 0x0C, 0xF3, 0xD4, 0xFF, 0xFF, 0xFF, 0xD7, 0xFF, 0xEF, 0xEB, 0xFF, 0x76, 0xEE, 0xFF,
                                    0x00, 0x00, 0x82, 0x9C, 0x8C, 0xA4, 0x04, 0x00, 0xF1, 0xA0, 0xF7, 0xF7, 0x00, 0x2C, 0x01, 0xD0,
                                    0xC7, 0xF8, 0x30, 0x51, 0x0C, 0x38, 0x00, 0xEB, 0x08, 0x05, 0x0E, 0xF1, 0x02, 0x0E, 0xF7, 0x46,
                                    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
                                    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
                                    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
                                    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
                                    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
                                    0xFF, 0xFF, 0xFF, 0xFF};
                //new m8t e-fuse
                //B5:62:06:41:80:00:E3:24:D5:9F:AC:FF:FF:FF:97:FE:
                //EF:CB:FF:76:EE:FF:00:00:82:9C:8C:A4:04:00:F1:A0:
                //F7:F7:00:2C:01:D0:C7:F8:30:51:0C:38:00:EB:08:05:
                //0E:F1:02:0E:F7:46:FF:FF:FF:FF:FF:FF:FF:FF:FF:
                //FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:
                //FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:
                //FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:
                //FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:
                //FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:E2:77:

            var packet_eFuse = new byte[]
                                    {0xB5, 0x62, 0x09, 0x21, 0x84+0x08+0x20, 0x00, 0x00, 0x00, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00,
                                  //0x46, 0x15, 0x0C, 0xF3, 0xD4, 0xFF, 0xFF, 0xFF, 0xD7, 0xFF, 0xEF, 0xEB, 0xFF, 0x76, 0xEE, 0xFF,
                                    0xE3, 0x24, 0xD5, 0x9F, 0xAC, 0xFF, 0xFF, 0xFF, 0x97, 0xFE, 0xEF, 0xCB, 0xFF, 0x76, 0xEE, 0xFF,
                                  //0x4C, 0xB4, 0x57, 0x5D, 0xD2, 0xFF, 0xFF, 0xFF, 0x07, 0xF8, 0xEF, 0xFB, 0xFF, 0x76, 0xEF, 0xFF,

                                    0x00, 0x00, 0x82, 0x9C, 0x8C, 0xA4, 0x04, 0x00, 0xF1, 0xA0, 0xF7, 0xF7, 0x00, 0x2C, 0x01, 0xD0,
                                    0xC7, 0xF8, 0x30, 0x51, 0x0C, 0x38, 0x00, 0xEB, 0x08, 0x05, 0x0E, 0xF1, 0x02, 0x0E, 0xF7, 0x46,
                                    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
                                    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
                                    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
                                    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
                                    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
                                    0xFF, 0xFF, 0xFF, 0xFF};
                var crc_ef = new ushort[0x40]; // every ushort is 2 bytes
                Buffer.BlockCopy(packet_eFuse, 14, crc_ef, 0, 0x80);
                var checksum_ef = E_Fusechecksum(packet_eFuse, packet_eFuse.Length, crc_ef, crc_ef.Length);

                for (var a = 0; a < packet_eFuse.Length; a++)
                {
                   // Console.Write(" " + packet_eFuse[a].ToString("X2"));
                }
                //Console.WriteLine();
                //for (var a = 0; a < checksum_ef.Length; a++)
                // {
                //     Console.Write(" " + checksum_ef[a].ToString("X2"));
                // }
                // Console.Write("->" + "C8 DB 47 47" + "  len=" + packet_eFuse.Length.ToString("X2"));
                // Console.WriteLine();

                var all_packet_ef = new byte[0x06 + 0x20 + 0x8C];
                var data_packet_ef = new byte[0x8C];
                Array.Copy(packet_eFuse, 6, data_packet_ef, 0, data_packet_ef.Length);
                for (var a = 0; a < data_packet_ef.Length; a++)
                {
                    //Console.Write(" " + data_packet_ef[a].ToString("X2"));
                }
                //Console.WriteLine();

                data_hash = sha256_sec(data_packet_ef);
                for (var a = 0; a < data_hash.Length; a++)
                {
                    //Console.Write(" " + data_hash[a].ToString("X2"));
                }
                //Console.WriteLine();
                Array.Copy(packet_eFuse, 0, all_packet_ef, 0, 6);
                Array.Copy(data_hash, 0, all_packet_ef, 6, 32);
                Array.Copy(packet_eFuse, 7, all_packet_ef, 39, 0x8B);
                for (var a = 0; a < all_packet_ef.Length; a++)
                {
                    Console.Write(" " + all_packet_ef[a].ToString("X2"));
                }

                var checksum = ubx_checksum(all_packet_ef, all_packet_ef.Length);
                for (var a = 0; a < checksum.Length; a++)
                {
                    Console.Write(" " + checksum[a].ToString("X2"));
                }
                Console.WriteLine();

                port.Write(all_packet_ef, 0, all_packet_ef.Length);
                port.Write(checksum, 0, checksum.Length);
                Console.Write("eFuse write");
                Console.WriteLine();



                return null;
            }



            req_sec = new uploadreq_sec();
            req_sec.head1 = 0xB5;// = 0xB5
            req_sec.head2 = 0x62;// = 0x62;
            req_sec.clas = 0x9;
            req_sec.subclass = 0x20;
            req_sec.length = 0x2C;
            //public static msginfo GetMsginfo1(byte cl, byte id)
            msginfo WriteWordSEC(uint startaddr, uint data)
            {
                byte[] data_hash = new byte[32];
                byte[] data_packet = new byte[12];
                req_downl_sec = new downl_sec();
                req_downl_sec.head1 = 0xB5;
                req_downl_sec.head2 = 0x62;
                req_downl_sec.clas = 0x9;
                req_downl_sec.subclass = 0x21;
                req_downl_sec.length = 0x2C;
                req_downl_sec.startaddr = startaddr;
                req_downl_sec.flags = 0; //0xE008 !!!
                req_downl_sec.data = data;
                var datastruct = StaticUtils.StructureToByteArray(req_downl_sec);
                Array.Copy(datastruct, 38, data_packet, 0, 12);
                data_hash = sha256_sec(data_packet);
                Array.Copy(data_hash, 0, datastruct, 6, 32);

                for (var a = 0; a < data_packet.Length; a++)
                {
                    //Console.Write(" " + data_packet[a].ToString("X2"));
                }
                //Console.WriteLine();
                for (var a = 0; a < data_hash.Length; a++)
                {
                    //Console.Write(" " + data_hash[a].ToString("X2"));
                }
                //Console.WriteLine();
                var checksum = ubx_checksum(datastruct, datastruct.Length);
                port.Write(datastruct, 0, datastruct.Length);
                port.Write(checksum, 0, checksum.Length);
                for (var a = 0; a < datastruct.Length; a++)
                {
                    //Console.Write(" " + datastruct[a].ToString("X2"));
                }
                for (var a = 0; a < checksum.Length; a++)
                {
                    //Console.Write(" " + checksum[a].ToString("X2"));
                }
                //Console.WriteLine();

                return null;
            }

            //0a 0d read LLC
            //06 41 read eFuse
            //!!!!!!!!!!!!!!!!!!!
            //WriteEFuseBBRAM(); //!!!
            Thread.Sleep(300);


            //WriteWordSEC(0x00200080, 0xFFFFFFED);
            //Thread.Sleep(300);
           // WriteWordSEC(0x2000004C, 0xFFFFFF69);
           // Thread.Sleep(300);
           //return;

            /*
            WriteWordSEC(0x20020934, 0x3B36D720);//20 D7 36 3B
            Thread.Sleep(100);
            WriteWordSEC(0x20020A38, 0x00010100);//00 01 01 00
            Thread.Sleep(100);
            WriteWordSEC(0x20020A40, 0x01010001);//01 00 01 01
            Thread.Sleep(100);
            WriteWordSEC(0x20020A50, 0x00010000);//00 00 01 00
            Thread.Sleep(100);
            WriteWordSEC(0x20020A5C, 0x00010100);//00 01 01 00
            Thread.Sleep(100);
            WriteWordSEC(0x20020A64, 0x01010001);//01 00 01 01
            Thread.Sleep(100);
            WriteWordSEC(0x20020A6C, 0x01000100);//00 01 00 01
            Thread.Sleep(100);
            WriteWordSEC(0x20020A84, 0x01010001);//01 00 01 01
            */
            //WriteWordSEC(0x200205A0, 0x03090009);//09 00 09 03
            //WriteWordSEC(0x20020934, 0x3B36D720);
            //Thread.Sleep(100);
            //WriteWordSEC(0x2000003C, 0xFFFFFF00);
            // Enable UBX
            //0xB5, 0x62, 0x06, 0x01, 0x08, 0x00, 0x02, 0x15, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x27, 0x4B, // RXM-RAWX on
            //0xB5, 0x62, 0x06, 0x01, 0x08, 0x00, 0x02, 0x13, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x25, 0x3D, // RXM-SFRBX on
            //$GPTXT,01,01,02,LLC 7FFFFFFF-FFFFFFED-FFFFFFFF-FFFFFF9E-FFFFFF69*2D
            //LLC=FFFFFFFF-FFFFFFED-FFFFFFFF-FFFFFFAE-FFFFFF69 NEO-M8T

            //WriteWordSEC(0x2000003C, 0x0);//its OK IF write this & REBOOT
            //Thread.Sleep(100);

            //WriteWordSEC(0x20000040, 0x0);
            //Thread.Sleep(100);
            /*
                      WriteWordSEC(0x20000030, 0x7FFFFFFF);//its OK IF write this & REBOOT
                      Thread.Sleep(100);
                      WriteWordSEC(0x20000034, 0xFFFFFFED);//its OK IF write this & REBOOT
                      Thread.Sleep(100);
                      WriteWordSEC(0x2000003C, 0xFFFFFF9E);//its OK IF write this & REBOOT
                      Thread.Sleep(100);
                      WriteWordSEC(0x20000040, 0xFFFFFF69);//its OK IF write this & REBOOT
                      Thread.Sleep(100);
          */
            /*
            WriteWordSEC(0x20000030, 0x0);
            Thread.Sleep(100);
            WriteWordSEC(0x20000034, 0x0);
            Thread.Sleep(100);
            WriteWordSEC(0x20000038, 0x0);
            Thread.Sleep(100);
            WriteWordSEC(0x2000003C, 0x0);
            Thread.Sleep(100);
            WriteWordSEC(0x20000040, 0x0);
            Thread.Sleep(100);
            */
            //0x40008000 GLONASS
            //0x40000000 GPS

            //WriteWordSEC(0x40008000, 0xF000);
            //WriteWordSEC(0x40008000, 0x010F0038);
            //WriteWordSEC(0x40008000, 0x010FFF38);
            Thread.Sleep(100);
            //WriteWordSEC(0x40000078, 0xffffffff);
            // WriteWordSEC(0x40000070, 0x1A);
            // WriteWordSEC(0x40008070, 0x1A);
            //0x40000070 <- 0x1A 
            //0x40008070 <- 0x1A 
            //00 00 00 00 03 04 00 00 00 00 00 00 00 60 F2 FF
            //38 00 0F 01 03 04 00 00 00 00 00 00 00 60 F2 FF
            //38 00 0F 00 03 04 00 00 00 00 00 00 00 80 F7 FF
            var deadline = DateTime.MinValue;
            uint lastaddr = 0;
            //0x2000C4E0
            //req_sec.startaddr = 0x08C;
            //req_sec.startaddr = 0x20000000;
            //req_sec.startaddr = 0x2009F000;
            //req_sec.startaddr = 0x20080000;
            //req_sec.startaddr = 0x40010000;
            //req_sec.startaddr = 0x40008070;
            // req_sec.startaddr = 0x2009F000;
            //req_sec.startaddr = 0x20000000;
            req_sec.startaddr = 0x00200000;//BBRAM
            // req_sec.startaddr = 0x00800000;//flash
            //req_sec.startaddr = 0x0000090;//ROM
            req_sec.datasize = 0x20;
            //req_sec.datasize = 0x10;
            req_sec.flags = 0xE008; //???  0x0
            //req_sec.flags = 0xFFFF; //???  0x0
            //req_sec.flags = 0xFFFFFFFF; //???  0x0
            req_sec.flags = 0x0; //???  0x0

            while (port.IsOpen)
            {
                // determine when to send a new/next request
                if (deadline < DateTime.Now )
                {
                    byte[] data_hash = new byte[32];
                    byte[] data_packet = new byte[12];
                    var datastruct = StaticUtils.StructureToByteArray(req_sec);
                    Array.Copy(datastruct, 38, data_packet, 0, 12);
                    data_hash = sha256_sec(data_packet);
                    Array.Copy(data_hash, 0, datastruct, 6, 32);


                    var checksum = ubx_checksum(datastruct, datastruct.Length);
                    port.Write(datastruct, 0, datastruct.Length);
                    port.Write(checksum, 0, checksum.Length);

                    deadline = DateTime.Now.AddMilliseconds(20);
 
                }

                Thread.Sleep(0);

                while (port.BytesToRead > 0)
                {
                    var data = (byte) port.ReadByte();

                    processbyte(data);
                }
                
                //if (adr_now >= 0x00088000)
                //if (adr_now >= 0x0088FFFF)
                if (adr_now >= 0x00207FFF)
                    {
                        Console.WriteLine();
                    Console.Write("BBRAM copy to bbramdata.bin");
                    //Console.Write("Flash copy to flashdata.bin");
                    //Console.Write("ROM copy to romdata.bin");
                    Console.WriteLine();
                    break;
                }

            }
        }


        private static void processbyte(byte data)
        {
            switch (UBX_step) //Normally we start from zero. This is a state machine
            {
                case 0:
                    if (data == 0xB5) // UBX sync char 1
                        UBX_step++; //OH first data packet is correct, so jump to the next step
                    break;
                case 1:
                    if (data == 0x62) // UBX sync char 2
                        UBX_step++; //ooh! The second data packet is correct, jump to the step 2
                    else
                        UBX_step = 0; //Nop, is not correct so restart to step zero and try again.     
                    break;
                case 2:
                    UBX_class = data;
                    ubx_checksum(UBX_class);
                    UBX_step++;
                    break;
                case 3:
                    UBX_id = data;
                    ubx_checksum(UBX_id);
                    UBX_step++;
                    break;
                case 4:
                    UBX_payload_length_hi = data;
                    ubx_checksum(UBX_payload_length_hi);
                    UBX_step++;
                    // We check if the payload lenght is valid...
                    if (UBX_payload_length_hi >= UBX_MAXPAYLOAD)
                    {
                        UBX_step = 0; //Bad data, so restart to step zero and try again.     
                        ck_a = 0;
                        ck_b = 0;
                    }
                    break;
                case 5:
                    UBX_payload_length_lo = data;
                    ubx_checksum(UBX_payload_length_lo);
                    UBX_step++;
                    UBX_payload_counter = 0;
                    break;
                case 6: // Payload data read...
                    if (UBX_payload_counter < UBX_payload_length_hi)
                        // We stay in this state until we reach the payload_length
                    {
                        UBX_buffer[UBX_payload_counter] = data;
                        ubx_checksum(data);
                        UBX_payload_counter++;
                        if (UBX_payload_counter == UBX_payload_length_hi)
                            UBX_step++;
                    }
                    break;
                case 7:
                    UBX_ck_a = data; // First checksum byte
                    UBX_step++;
                    break;
                case 8:
                    UBX_ck_b = data; // Second checksum byte

                    // We end the GPS read...
                    if ((ck_a == UBX_ck_a) && (ck_b == UBX_ck_b))
                    {
                        // Verify the received checksum with the generated checksum.. 
                        // Parse the new GPS packet


                        if (UBX_class == 0x9 && UBX_id == 0x20)
                            {
                             //var resp = UBX_buffer.ByteArrayToStructure<uploadresp>(0);
                             var resp = UBX_buffer.ByteArrayToStructure<uploadresp_9_20_D>(0);
                            for (var a = 0; a < resp.datasize; a++)
                            {
                                //Console.Write(" " + resp.data[a].ToString("X2"));
                            }
                            adr_now = resp.startaddr;
                            Console.WriteLine();
                            Console.Write("0x{0:X8} ", resp.startaddr);
                            //Console.Write("0x{0:X2} -> ", resp.datasize);
                            /*
                            Console.Write("0x{0:X8} ", resp.dat0);
                            Console.Write("0x{0:X8} ", resp.dat1);
                            Console.Write("0x{0:X8} ", resp.dat2);
                            Console.WriteLine("0x{0:X8}", resp.dat3);
                            */
                            bw.Seek((int) (resp.startaddr & 0xFFFFF), SeekOrigin.Begin);
                            bw.Write(resp.data, 0, (int)resp.datasize);
                            if (req_sec.startaddr == resp.startaddr) req_sec.startaddr += req_sec.datasize;
                        }
                        else
                        {
                           // Console.WriteLine(DateTime.Now + "we have a packet 0x" + UBX_class.ToString("X") + " 0x" +
                           //                   UBX_id.ToString("X") + " " + UBX_payload_counter);
                        }
                    }
                    // Variable initialization
                    UBX_step = 0;
                    ck_a = 0;
                    ck_b = 0;

                    break;
            }
        }

 
        private static void ubx_checksum(byte ubx_data)
        {
            ck_a += ubx_data;
            ck_b += ck_a;
        }

        private static byte[] ubx_checksum(byte[] packet, int size, int offset = 2)
        {
            uint a = 0x00;
            uint b = 0x00;
            var i = offset;
            while (i < size)
            {
                a += packet[i++];
                b += a;
            }

            var ans = new byte[2];

            ans[0] = (byte)(a & 0xFF);
            ans[1] = (byte)(b & 0xFF);

            return ans;
        }

        private static byte[] E_Fusechecksum(byte[] packet_eFuse, int size_ef, UInt16[] packet, int size)
        {
            var ans = new byte[4];
            uint st_word = 0xBAADF00D;
            var i = 0;
            uint a = 0x00;
            uint b = 0x00;
            UInt32 st_hwH = st_word >> 0x10;
            UInt32 st_hwL = st_word & 0xFFFF;

            while (i < size )
            {
                st_hwL += (UInt16)packet[i];
                st_hwH += st_hwL;
                i++;
            }
            st_hwL = st_hwL & 0xFFFF;
            st_hwH = (st_hwH & 0xFFFF) << 0x10;
            st_hwL = st_hwL | st_hwH;
            packet_eFuse[size_ef - 4] = (byte)(st_hwL & 0xFF);
            packet_eFuse[size_ef - 3] = (byte)((st_hwL >> 0x08) & 0xFF);
            packet_eFuse[size_ef - 2] = (byte)((st_hwL >> 0x10) & 0xFF);
            packet_eFuse[size_ef - 1] = (byte)((st_hwL >> 0x18) & 0xFF);

            ans[0] = (byte)(st_hwL & 0xFF);
            ans[1] = (byte)((st_hwL >> 0x08) & 0xFF);
            ans[2] = (byte)((st_hwL >> 0x10) & 0xFF);
            ans[3] = (byte)((st_hwL >> 0x18) & 0xFF);
            return ans;

        }


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private struct uploadresp
        {
            public readonly uint startaddr;
            public readonly uint datasize;
            public readonly uint flags;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)] public readonly byte[] data;
        }

        private struct uploadresp_9_20
        {

            public readonly uint rez;
            public readonly uint rez1;
            public readonly uint rez2;
            public readonly uint rez3;
            public readonly uint rez4;
            public readonly uint rez5;
            public readonly uint rez6;
            public readonly uint rez7;
            public readonly uint startaddr;
            public readonly uint datasize;
            public readonly uint flags;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)] public readonly byte[] data;
        }

        private struct uploadresp_9_20_D
        {

            public readonly uint rez;
            public readonly uint rez1;
            public readonly uint rez2;
            public readonly uint rez3;
            public readonly uint rez4;
            public readonly uint rez5;
            public readonly uint rez6;
            public readonly uint rez7;
            public readonly uint startaddr;
            public readonly uint datasize;
            public readonly uint flags;
            //            public readonly uint dat0;
            //            public readonly uint dat1;
            //            public readonly uint dat2;
            //            public readonly uint dat3;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)] public readonly byte[] data;
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private struct downloadreq
        {
            public byte clas;
            public byte subclass;
            public ushort length;
            public uint startaddr;
            public uint flags;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)] public byte[] data;
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private struct uploadreq
        {
            public byte head1;// = 0xB5 62;
            public byte head2;// = 0x62;
            public byte clas;// = 9;
            public byte subclass;// = 2;
            public ushort length;
            public uint startaddr;
            public uint datasize;
            public uint flags;
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private struct uploadreq_sec
        {
            public byte head1;// = 0xB5 62;
            public byte head2;// = 0x62;
            public byte clas;// = 9;
            public byte subclass;// = 0x20;
            public ushort length;
            //public byte[] hash;
            public UInt64 val1;
            public UInt64 val2;
            public UInt64 val3;
            public UInt64 val4;
            public uint startaddr;
            public uint datasize;
            public uint flags;
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private struct downl_sec
        {
            public byte head1;// = 0xB5 62;
            public byte head2;// = 0x62;
            public byte clas;// = 9;
            public byte subclass;// = 0x21;
            public ushort length;
            public UInt64 val1;
            public UInt64 val2;
            public UInt64 val3;
            public UInt64 val4;
            public uint startaddr;
            public uint flags;
            public uint data;
        }
    }
}
//B5 62 09 20 2C 00 9C 59 C5 22 EC 34 1A 1A 30 
//CC B1 FB 69 CB AD 9A 41 83 6E DD 27 E4 FB A6 8C 71 E3 AB 8A A4 0D 20 FC 7F 08 00 04 00 00 00 00 00 00 00 D0 44  
//    46 15 0C F3 D4 FF FF FF D7 FF EF EB FF 76 EE FF 00 00 82 9C 8C A4 04 00 F1 A0 F7 F7 00 2C 01 D0 C7 F8 30 51 0C 38 00 EB 08 05 0E F1 02 0E F7 46 FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF 4A 13
//    4C B4 57 5D D2 FF FF FF 07 F8 AF FB FF 76 EF FF 92 EE 94 0B 0D 0E 0E 0E 0D 0C 0A 08 06 05 05 05 07 08 09 FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF A7 0A    
// A1 9F A3 
// 0x9B 1 0x30 1 0x94 0x10 0x89 2 0x90 3 0x91 1 0x31 1 x92 1

//new m8t e-fuse
//B5:62:06:41:80:00:E3:24:D5:9F:AC:FF:FF:FF:97:FE:
//EF:CB:FF:76:EE:FF:00:00:82:9C:8C:A4:04:00:F1:A0:
//F7:F7:00:2C:01:D0:C7:F8:30:51:0C:38:00:EB:08:05:
//0E:F1:02:0E:F7:46:FF:FF:FF:FF:FF:FF:FF:FF:FF:
//FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:
//FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:
//FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:
//FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:
//FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:FF:E2:77:

//ROM BASE 2.01 (75331)
//B5 62 06 41 80 00 46 15 0C F3 D4 FF FF FF D7 FF 
//EF EB FF 76 EE FF 00 00 82 9C 8C A4 04 00 F1 A0 
//F7 F7 00 2C 01 D0 C7 F8 30 51 0C 38 00 EB 08 05 
//0E F1 02 0E F7 46 FF FF FF FF FF FF FF FF FF FF 
//FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF 
//FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF 
//FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF 
//FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF 
//FF FF FF FF FF FF 4A 13
