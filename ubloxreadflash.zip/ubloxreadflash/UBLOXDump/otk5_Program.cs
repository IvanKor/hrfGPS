﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using MissionPlanner.Comms;


namespace UBLOXDump
{
    internal class Program
    {

        [DllImport("sha256.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
        static extern void sha256_starts(byte[] ctx);

        [DllImport("sha256.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
        static extern void sha256_update(byte[] ctx, byte[] input, uint length);

        [DllImport("sha256.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
        static extern void sha256_finish(byte[] ctx, byte[] digest);

        private static readonly BinaryWriter bw =
            new BinaryWriter(File.Open("data.raw", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.Read));

        private static byte UBX_class;
        private static byte UBX_id;
        private static byte UBX_payload_length_hi;
        private static readonly int UBX_MAXPAYLOAD = 1000;
        private static byte ck_a;
        private static byte ck_b;
        private static byte UBX_payload_length_lo;
        private static byte UBX_ck_a;
        private static byte UBX_ck_b;
        private static int UBX_payload_counter;
        private static readonly byte[] UBX_buffer = new byte[256];

        private static int UBX_step;
        private static uploadreq req;
        private static uploadreq_sec req_sec;
        private static downl_sec req_downl_sec;

        //http://gps.0xdc.ru/wiki/doku.php?id=u-blox_undocumented_messages

        public class msginfo
        {
            public string name;
            public byte cl;
            public byte id;

            public msginfo()
            {

            }

            public msginfo(string name, byte cl, byte id)
            {
                this.name = name;
                this.cl = cl;
                this.id = id;
            }
        }

        /* 
*v8 09 0b - set addr // B5 62 09 0B 05 00 00 00 80 00 01 9A 4D
*   09 0c - data
*   09 0d
*   09 07 - safeboot
*   09 0e - finish
*   09 06 - identify
*   09 21 - UPD-DOWNL
*   09 08 - start addr ? // B5 62 09 08 04 00 00 00 80 00 95 98
*   09 20 - UPD-UPLOAD
*/
        public static List<msginfo> msglist = new List<msginfo>()
        {
            new msginfo("ACK-ACK", 0x05, 0x01),
            new msginfo("ACK-NACK", 0x05, 0x00),
            new msginfo("AID-ALM", 0x0b, 0x30),
            new msginfo("AID-ALPSRV", 0XB, 0x32),
            new msginfo("AID-AOP", 0XB, 0x33),
            new msginfo("AID-DATA", 0x0b, 0x10),
            new msginfo("AID-EPH", 0x0b, 0x31),
            new msginfo("AID-HUI", 0x0b, 0x02),
            new msginfo("AID-INI", 0x0b, 0x01),
            new msginfo("AID-REQ", 0x0b, 0x00),
            new msginfo("CFG-ANT", 0x06, 0x13),
            new msginfo("CFG-CFG", 0x06, 0x09),
            new msginfo("CFG-DAT", 0x06, 0x06),
            new msginfo("CFG-EKF", 0x06, 0x12),
            new msginfo("CFG-FXN", 0x06, 0x0e),
            new msginfo("CFG-INF", 0x06, 0x02),
            new msginfo("CFG-LIC", 0x06, 0x80),
            new msginfo("CFG-MSG", 0x06, 0x01),
            new msginfo("CFG-NAV2", 0x06, 0x1a),
            new msginfo("CFG-NMEA", 0x06, 0x17),
            new msginfo("CFG-PRT", 0x06, 0x00),
            new msginfo("CFG-RATE", 0x06, 0x08),
            new msginfo("CFG-RST", 0x06, 0x04),
            new msginfo("CFG-PWR", 0x06, 0x57),
            new msginfo("CFG-RXM", 0x06, 0x11),
            new msginfo("CFG-SBAS", 0x06, 0x16),
            new msginfo("CFG-TM", 0x06, 0x10),
            new msginfo("CFG-TM2", 0x06, 0x19),
            new msginfo("CFG-TMODE", 0x06, 0x1d),
            new msginfo("CFG-TMODE3", 6, 0x71),
            new msginfo("CFG-TP", 0x06, 0x07),
            new msginfo("CFG-USB", 0x06, 0x1b),
            new msginfo("CFG-GEOFENCE", 0x06, 0x69),
            new msginfo("CFG-GNSS", 0x06, 0x3e),
            new msginfo("INF-DEBUG", 0x04, 0x04),
            new msginfo("INF-ERROR", 0x04, 0x00),
            new msginfo("INF-NOTICE", 0x04, 0x02),
            new msginfo("INF-TEST", 0x04, 0x03),
            new msginfo("INF-USER", 0x04, 0x07),
            new msginfo("INF-WARNING", 0x04, 0x01),
            new msginfo("LOG-INFO", 0X21, 8),
            new msginfo("MON-EXCEPT", 0x0a, 0x05),
            new msginfo("MON-HW", 0x0a, 0x09),
            new msginfo("MON-HW2", 0XA, 0XB),
            new msginfo("MON-IO", 0x0a, 0x02),
            new msginfo("MON-IPC", 0x0a, 0x03),
            new msginfo("MON-LLC", 0xa, 0xd),
            new msginfo("MON-MSGPP", 0x0a, 0x06),
            new msginfo("MON-RXBUF", 0x0a, 0x07),
            new msginfo("MON-SCHD", 0x0a, 0x01),
            new msginfo("MON-SPEC", 0x0a, 0x1d),
            new msginfo("MON-RXR", 0x0a, 0x21),
            new msginfo("MON-TXBUF", 0x0a, 0x08),
            new msginfo("MON-USB", 0x0a, 0x0a),
            new msginfo("MON-VER", 0x0a, 0x04),
            new msginfo("NAV-AOPSTATUS", 0x01, 0X60),
            new msginfo("NAV-EOE", 0x01, 0X61),
            new msginfo("NAV-CLOCK", 0x01, 0x22),
            new msginfo("NAV-DGPS", 0x01, 0x31),
            new msginfo("NAV-DOP", 0x01, 0x04),
            new msginfo("NAV-EKFSTATUS", 0x01, 0x40),
            new msginfo("NAV-GEOFENCE", 0X1, 0X39),
            new msginfo("NAV-ODO", 0X1, 0X9),
            new msginfo("NAV-ORB", 0X1, 0X34),
            new msginfo("NAV-POSECEF", 0x01, 0x01),
            new msginfo("NAV-POSLLH", 0x01, 0x02),
            new msginfo("NAV-POSUTM", 0x01, 0x08),
            new msginfo("NAV-PVT", 0x01, 0x07),
            new msginfo("NAV-RELPOSNED", 0X1, 0X3C),
            new msginfo("NAV-SAT", 0X1, 0X35),
            new msginfo("NAV-SBAS", 0x01, 0x32),
            new msginfo("NAV-SOL", 0x01, 0x06),
            new msginfo("NAV-STATUS", 0x01, 0x03),
            new msginfo("NAV-SVIN", 0X1, 0X3B),
            new msginfo("NAV-SVINFO", 0x01, 0x30),
            new msginfo("NAV-TIMEBDS", 0X1, 0X24),
            new msginfo("NAV-TIMEGAL", 0X1, 0X25),
            new msginfo("NAV-TIMEGLO", 0X1, 0X23),
            new msginfo("NAV-TIMEGPS", 0x01, 0x20),
            new msginfo("NAV-TIMELS", 0X1, 0X26),
            new msginfo("NAV-TIMEUTC", 0x01, 0x21),
            new msginfo("NAV-VELECEF", 0x01, 0x11),
            new msginfo("NAV-VELNED", 0x01, 0x12),
            new msginfo("NMEA", 0xf0, 0),
            new msginfo("NMEA", 0xf0, 1),
            new msginfo("NMEA", 0xf0, 10),
            new msginfo("NMEA", 0xf0, 11),
            new msginfo("NMEA", 0xf0, 12),
            new msginfo("NMEA", 0xf0, 13),
            new msginfo("NMEA", 0xf0, 14),
            new msginfo("NMEA", 0xf0, 15),
            new msginfo("NMEA", 0xf0, 2),
            new msginfo("NMEA", 0xf0, 3),
            new msginfo("NMEA", 0xf0, 4),
            new msginfo("NMEA", 0xf0, 5),
            new msginfo("NMEA", 0xf0, 6),
            new msginfo("NMEA", 0xf0, 7),
            new msginfo("NMEA", 0xf0, 8),
            new msginfo("NMEA", 0xf0, 9),
            new msginfo("NMEA", 0xf0, 0x40),
            new msginfo("NMEA", 0xf0, 0x42),
            new msginfo("NMEA", 0xf0, 0x43),
            new msginfo("NMEA", 0xf0, 0x44),
            new msginfo("pubx00", 0xf1, 0),
            new msginfo("pubx01", 0xf1, 1),
            new msginfo("pubx03", 0xf1, 3),
            new msginfo("pubx04", 0xf1, 4),
            new msginfo("PUBX-RATE", 0xf1, 0x40),
            new msginfo("PUBX-CONFIG", 0xf1, 0x41),

            new msginfo("RTCM1005", 0XF5, 0x05),/**< Stationary RTK reference station ARP */
            new msginfo("RTCM1074", 0XF5, 0x4A),/**< GPS MSM4 */
            new msginfo("RTCM1077", 0XF5, 0X4D),/**< GPS MSM7 */
            new msginfo("RTCM1084", 0XF5, 0X54),/**< GLONASS MSM4 */
            new msginfo("RTCM1087", 0XF5, 0X57),/**< GLONASS MSM7 */
            new msginfo("RTCM1094", 0XF5, 0X5E),/**< GALILEO MSM4 */
            new msginfo("RTCM1097", 0XF5, 0X61),/**< GALILEO MSM7 */
            new msginfo("RTCM1124", 0XF5, 0X7C),/**< BeiDou MSM4 */
            new msginfo("RTCM1127", 0XF5, 0X7F),/**< BeiDou MSM7 */
            new msginfo("RTCM1230", 0XF5, 0XE6),/**< GLONASS code-phase biases */
            new msginfo("RTCM4072", 0XF5, 0xFE),/**< Reference station PVT (u-blox proprietary RTCM Message) - Used for moving baseline */

            new msginfo("MGA-GPS", 0x13, 0x00),
            new msginfo("MGA-GAL", 0x13, 0x02),
            new msginfo("MGA-BDS", 0x13, 0x03),
            new msginfo("MGA-QZSS-EPH", 0x13, 0x05),
            new msginfo("MGA-GPS-TIMEOFFSET", 0x13, 0x06),
            new msginfo("MGA-MGA-INI", 0x13, 0x40),
            new msginfo("MGA-DBD", 0x13, 0x80),
            new msginfo("MGA-ANO", 0x13, 0x20),
            new msginfo("MGA-FLASH", 0x13, 0x21),

            new msginfo("RXM-ALM", 0x02, 0x30),
            new msginfo("RXM-EPH", 0x02, 0x31),
            new msginfo("RXM-EPH", 0x02, 0x31),
            new msginfo("RXM-MEASX", 0x02, 0x14),
            new msginfo("RXM-POSREQ", 0x02, 0x40),
            new msginfo("RXM-RAW", 0x02, 0x10),
            new msginfo("RXM-RAWX", 0x02, 0x15),
            new msginfo("RXM-SFRB", 0x02, 0x11),
            new msginfo("RXM-SFRBX", 0x02, 0x13),
            new msginfo("RXM-SVSI", 0x02, 0x20),
            new msginfo("RXM-RLM", 0x02, 0x59),
            new msginfo("RXM-IMES", 0x02, 0x61),
            new msginfo("SEC-SIGN", 0X27, 1),
            new msginfo("SEC-UNIQID", 0X27, 3),
            new msginfo("TIM-SVIN", 0x0d, 0x04),
            new msginfo("TIM-TM", 0x0d, 0x02),
            new msginfo("TIM-TM2", 0x0d, 0x03),
            new msginfo("TIM-TP", 0x0d, 0x01),
            new msginfo("TIM-VRFY", 0x0d, 0x06),
            new msginfo("TRK-MEAS", 3, 0x10),
            new msginfo("TRK-SFRB", 3, 0x2),
            new msginfo("TRK-SFRBX", 3, 0xf),
            new msginfo("TRK-TRKD2", 3, 0x6),
            new msginfo("TRK-TRKD5", 3, 0x0a),
            new msginfo("UPD", 9, 0xff),
            new msginfo("UPD-csum", 9, 0xd),
            new msginfo("UPD-DOWNL", 0x09, 0x01),
            new msginfo("UPD-DOWNL-SEC", 0x09, 0x21),
            new msginfo("UPD-erase", 9, 0xb),
            new msginfo("UPD-EXEC", 0x09, 0x03),
            new msginfo("UPD-EXEC-SEC", 0x09, 0x22),
            new msginfo("UPD-FLDET", 9, 8),
            new msginfo("UPD-identify", 9, 6),
            new msginfo("UPD-MEMCPY", 0x09, 0x04),
            new msginfo("UPD-RBOOT", 9, 0xe), // EXIT
            new msginfo("UPD-SAFE", 9, 7), // ENTER
            new msginfo("UPD-SOS", 9, 0x14),
            new msginfo("UPD-UPLOAD", 0x09, 0x02),
            new msginfo("UPD-UPLOAD-SEC", 0x09, 0x20),
            new msginfo("UPD-write", 9, 0xc),

        };

        public static msginfo GetMsginfo(byte cl, byte id)
        {
            var list = msglist.Where(a => a.cl == cl && a.id == id);

            if (list.Count() == 0)
                return new msginfo("UNKNOWN", 0, 0);

            return list.First();
        }
        //63 F6 8C BA
        //BA8CF663
        //0x6D9BC8
        //0x86AF74
        //
        static byte[] sha256_sec(byte[] packet)
        {
            byte[] ctx = new byte[104] ; // 104 => sizeof(sha256_ctx)
            byte[] hash = new byte[32]; //  32 => 256-bit sha256
            var FixedHi = new byte[] { 0x63, 0x73, 0xD6, 0x62 };
            var FixedLo = new byte[] { 0x35, 0x53, 0xA1, 0x96 };

            sha256_starts(ctx);
            sha256_update(ctx, FixedHi, 4); // FIXED HI
            sha256_update(ctx, packet,(uint) packet.Length);
            sha256_update(ctx, FixedLo, 4); // FIXED LO
            sha256_finish(ctx, hash);

            return hash;

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="file">raw dump</param>
        /// <param name="outputfile">output</param>
        /// <param name="startoffset">Memory location</param>
        /// <param name="secondsoffset">Flash location</param>
        private static void ExtractPacketAddresses(string file, string outputfile, int startoffset,
            int secondsoffset = 0, bool m8 = false)
        {
            if (!File.Exists(file))
                return;

            TextWriter tw = new StreamWriter(outputfile);

            var br = new BinaryReader(File.OpenRead(file));

            // 0x1420 - 6m
            // 0x3e4c - 7n

            br.BaseStream.Seek(startoffset, SeekOrigin.Begin);

            var lowestoffset = uint.MaxValue;

            while (br.BaseStream.Position < (startoffset + 4000))
            {
                var posstart = br.BaseStream.Position;
                var addr = br.ReadUInt32();
                if (addr != 0)
                    lowestoffset = Math.Min(addr, lowestoffset);
                br.BaseStream.Seek(2, SeekOrigin.Current);
                var clas = br.ReadByte();
                var subclas = br.ReadByte();
                br.BaseStream.Seek(12, SeekOrigin.Current);

                var pos = br.BaseStream.Position;

                ulong ch = 0;

                if (br.BaseStream.Length > addr)
                {
                    br.BaseStream.Seek(addr, SeekOrigin.Begin);

                    ch = br.ReadUInt64();

                    br.BaseStream.Seek(pos, SeekOrigin.Begin);
                }

                var type = GetMsginfo(clas, subclas);

                var name = type.name;

                tw.WriteLine(posstart.ToString("X") + "\t" + clas.ToString("X") + "\t" + subclas.ToString("X") + "\t" +
                             addr.ToString("X") + "\t" + ch.ToString("X") + "\t" + name);
            }

            //
            while (br.BaseStream.Position < (startoffset + 2000 + 320))
            {
                var addr = br.ReadUInt32();
                tw.WriteLine(addr.ToString("X"));
            }

            tw.WriteLine("Message in FW");

            //second
            if (secondsoffset > 0)
            {
                br.BaseStream.Seek(secondsoffset, SeekOrigin.Begin);

                try
                {
                    while (br.BaseStream.Position < (secondsoffset + 0x928))
                    {
                        var posstart = br.BaseStream.Position;

                        var clas = br.ReadByte();
                        var subclas = br.ReadByte();
                        var zero = br.ReadByte();
                        var priorite = br.ReadByte();

                        //br.BaseStream.Seek(2, SeekOrigin.Current);

                        var addr = br.ReadUInt32();

                        if (!m8)
                            br.BaseStream.Seek(4, SeekOrigin.Current);

                        if (clas == 0 && subclas == 0)
                            continue;

                        var type = GetMsginfo(clas, subclas);

                        var name = type.name;

                        tw.WriteLine(posstart.ToString("X") + "\t" + clas.ToString("X") + "\t" + subclas.ToString("X") +
                                     "\t" + zero.ToString("X") + "\t" + priorite.ToString("X") +
                                     "\t" + addr.ToString("X") + "\t" + name);
                    }
                }
                catch
                {
                }
            }

            tw.Close();

            br.Close();
        }
        private static void ExtractPacketAddresses8N(string file, string outputfile, int startoffset,
            int secondsoffset = 0, bool m8 = false)
        {
            if (!File.Exists(file))
                return;

            TextWriter tw = new StreamWriter(outputfile);

            var br = new BinaryReader(File.OpenRead(file));

            // 0x1420 - 6m
            // 0x3e4c - 7n

            br.BaseStream.Seek(startoffset, SeekOrigin.Begin);

            var lowestoffset = uint.MaxValue;

            while (br.BaseStream.Position < (startoffset + 4000))
            {
                var posstart = br.BaseStream.Position;
                var addr = br.ReadUInt32();
                if (addr != 0)
                    lowestoffset = Math.Min(addr, lowestoffset);
                br.BaseStream.Seek(2, SeekOrigin.Current);
                var clas = br.ReadByte();
                var subclas = br.ReadByte();
                br.BaseStream.Seek(12, SeekOrigin.Current);

                var pos = br.BaseStream.Position;

                ulong ch = 0;

                if (br.BaseStream.Length > addr)
                {
                    br.BaseStream.Seek(addr, SeekOrigin.Begin);

                    ch = br.ReadUInt64();

                    br.BaseStream.Seek(pos, SeekOrigin.Begin);
                }

                var type = GetMsginfo(clas, subclas);

                var name = type.name;

                tw.WriteLine(posstart.ToString("X") + "\t" + clas.ToString("X") + "\t" + subclas.ToString("X") + "\t" +
                             addr.ToString("X") + "\t" + ch.ToString("X") + "\t" + name);
            }

            //
            while (br.BaseStream.Position < (startoffset + 2000 + 320))
            {
                var addr = br.ReadUInt32();
                tw.WriteLine(addr.ToString("X"));
            }

            tw.WriteLine("Message in FW");

            //second
            if (secondsoffset > 0)
            {
                br.BaseStream.Seek(secondsoffset, SeekOrigin.Begin);

                try
                {
                    while (br.BaseStream.Position < (secondsoffset + 0x928 + 336))
                    {
                        var posstart = br.BaseStream.Position;

                        var clas = br.ReadByte();
                        var subclas = br.ReadByte();
                        var zero = br.ReadByte();
                        var priorite = br.ReadByte();

                        //br.BaseStream.Seek(2, SeekOrigin.Current);

                        var addr = br.ReadUInt32();

                        if (!m8)
                            br.BaseStream.Seek(4, SeekOrigin.Current);

                        if (clas == 0 && subclas == 0)
                            continue;

                        var type = GetMsginfo(clas, subclas);

                        var name = type.name;

                        tw.WriteLine(posstart.ToString("X") + "\t" + clas.ToString("X") + "\t" + subclas.ToString("X") +
                                     "\t" + zero.ToString("X") + "\t" + priorite.ToString("X") +
                                     "\t" + addr.ToString("X") + "\t" + name);
                    }
                }
                catch
                {
                }
            }

            tw.Close();

            br.Close();
        }

        private static void ExtractPacketAddresses8T(string file, string outputfile, int startoffset,
            int secondsoffset = 0, bool m8 = false)
        {
            if (!File.Exists(file))
                return;

            TextWriter tw = new StreamWriter(outputfile);

            var br = new BinaryReader(File.OpenRead(file));

            // 0x1420 - 6m
            // 0x3e4c - 7n

            br.BaseStream.Seek(startoffset, SeekOrigin.Begin);

            var lowestoffset = uint.MaxValue;

            while (br.BaseStream.Position < (startoffset + 4000))
            {
                var posstart = br.BaseStream.Position;
                var addr = br.ReadUInt32();
                if (addr != 0)
                    lowestoffset = Math.Min(addr, lowestoffset);
                br.BaseStream.Seek(2, SeekOrigin.Current);
                var clas = br.ReadByte();
                var subclas = br.ReadByte();
                br.BaseStream.Seek(12, SeekOrigin.Current);

                var pos = br.BaseStream.Position;

                ulong ch = 0;

                if (br.BaseStream.Length > addr)
                {
                    br.BaseStream.Seek(addr, SeekOrigin.Begin);

                    ch = br.ReadUInt64();

                    br.BaseStream.Seek(pos, SeekOrigin.Begin);
                }

                var type = GetMsginfo(clas, subclas);

                var name = type.name;

                tw.WriteLine(posstart.ToString("X") + "\t" + clas.ToString("X") + "\t" + subclas.ToString("X") + "\t" +
                             addr.ToString("X") + "\t" + ch.ToString("X") + "\t" + name);
            }

            //
            while (br.BaseStream.Position < (startoffset + 2000 + 320))
            {
                var addr = br.ReadUInt32();
                tw.WriteLine(addr.ToString("X"));
            }

            tw.WriteLine("Message in FW");

            //second
            if (secondsoffset > 0)
            {
                br.BaseStream.Seek(secondsoffset, SeekOrigin.Begin);

                try
                {
                    while (br.BaseStream.Position < (secondsoffset + 0x928 + 368))
                    {
                        var posstart = br.BaseStream.Position;

                        var clas = br.ReadByte();
                        var subclas = br.ReadByte();
                        var zero = br.ReadByte();
                        var priorite = br.ReadByte();

                        //br.BaseStream.Seek(2, SeekOrigin.Current);

                        var addr = br.ReadUInt32();

                        if (!m8)
                            br.BaseStream.Seek(4, SeekOrigin.Current);

                        if (clas == 0 && subclas == 0)
                            continue;

                        var type = GetMsginfo(clas, subclas);

                        var name = type.name;

                        tw.WriteLine(posstart.ToString("X") + "\t" + clas.ToString("X") + "\t" + subclas.ToString("X") +
                                     "\t" + zero.ToString("X") + "\t" + priorite.ToString("X") +
                                     "\t" + addr.ToString("X") + "\t" + name);
                    }
                }
                catch
                {
                }
            }

            tw.Close();

            br.Close();
        }



        private static void ExtractPacketAddresses8PREF(string file, string outputfile, int startoffset,
            int secondsoffset = 0, bool m8 = false)
        {
            if (!File.Exists(file))
                return;

            TextWriter tw = new StreamWriter(outputfile);

            var br = new BinaryReader(File.OpenRead(file));

            // 0x1420 - 6m
            // 0x3e4c - 7n

            br.BaseStream.Seek(startoffset, SeekOrigin.Begin);

            var lowestoffset = uint.MaxValue;

            while (br.BaseStream.Position < (startoffset + 4000))
            {
                var posstart = br.BaseStream.Position;
                var addr = br.ReadUInt32();
                if (addr != 0)
                    lowestoffset = Math.Min(addr, lowestoffset);
                br.BaseStream.Seek(2, SeekOrigin.Current);
                var clas = br.ReadByte();
                var subclas = br.ReadByte();
                br.BaseStream.Seek(12, SeekOrigin.Current);

                var pos = br.BaseStream.Position;

                ulong ch = 0;

                if (br.BaseStream.Length > addr)
                {
                    br.BaseStream.Seek(addr, SeekOrigin.Begin);

                    ch = br.ReadUInt64();

                    br.BaseStream.Seek(pos, SeekOrigin.Begin);
                }

                var type = GetMsginfo(clas, subclas);

                var name = type.name;

                tw.WriteLine(posstart.ToString("X") + "\t" + clas.ToString("X") + "\t" + subclas.ToString("X") + "\t" +
                             addr.ToString("X") + "\t" + ch.ToString("X") + "\t" + name);
            }

            //
            while (br.BaseStream.Position < (startoffset + 2000 + 320))
            {
                var addr = br.ReadUInt32();
                tw.WriteLine(addr.ToString("X"));
            }

            tw.WriteLine("Message in FW");

            //second
            if (secondsoffset > 0)
            {
                br.BaseStream.Seek(secondsoffset, SeekOrigin.Begin);

                try
                {
                    while (br.BaseStream.Position < (secondsoffset + 0x928 + 368 + 760))
                    {
                        var posstart = br.BaseStream.Position;

                        var clas = br.ReadByte();
                        var subclas = br.ReadByte();
                        var zero = br.ReadByte();
                        var priorite = br.ReadByte();

                        //br.BaseStream.Seek(2, SeekOrigin.Current);

                        var addr = br.ReadUInt32();

                        if (!m8)
                            br.BaseStream.Seek(4, SeekOrigin.Current);

                        if (clas == 0 && subclas == 0)
                            continue;

                        var type = GetMsginfo(clas, subclas);

                        var name = type.name;

                        tw.WriteLine(posstart.ToString("X") + "\t" + clas.ToString("X") + "\t" + subclas.ToString("X") +
                                     "\t" + zero.ToString("X") + "\t" + priorite.ToString("X") +
                                     "\t" + addr.ToString("X") + "\t" + name);
                    }
                }
                catch
                {
                }
            }

            tw.Close();

            br.Close();
        }



        private static void Main(string[] args)
        {

            ExtractPacketAddresses("UBLOX_M8_201.89cc4f1cd4312a0ac1b56c790f7c1622.bin",
                "Addr8_201.txt", 0, 0x739e8);
            ExtractPacketAddresses("FW101_EXT_TITLIS.42ec35ce38d201fd723f2c8b49b6a537.bin",
                "Addr7.txt", 0, 0x62f0c);
            ExtractPacketAddresses("EXT_G60_LEA-6H.bin",
                "Addr6.txt", 0, 0x546DC);
            ExtractPacketAddresses8N("UBX_M8_301_SPG.911f2b77b649eb90f4be14ce56717b49.bin",
                "Addr8N_301.txt", 0, 0x7904c, true);
            ExtractPacketAddresses8N("301ROM.bin",
                "Addr8N_301_ROM.txt", 0, 0x84B0C, true);
            ExtractPacketAddresses8T("M8T_3.01.bin",
                "Addr8T_301.txt", 0, 0x7A998, true);
            ExtractPacketAddresses8PREF("301_140_REFERENCE.bin",
                "Addr8PREF_301.txt", 0, 0x73990, true);

            //return;

            ICommsSerial port;
            port = new MissionPlanner.Comms.SerialPort();

            //port.PortName = "com9";
            port.PortName = "com2";
            //port.BaudRate = 9600;
            port.BaudRate = 115200;
            port.ReadBufferSize = 1024*1024;
            port.Open();

            req_sec = new uploadreq_sec();
            req_sec.head1 = 0xB5;// = 0xB5
            req_sec.head2 = 0x62;// = 0x62;
            req_sec.clas = 0x9;
            req_sec.subclass = 0x20;
            req_sec.length = 0x2C;

            //public static msginfo GetMsginfo1(byte cl, byte id)
            msginfo GetMsginfo1(uint startaddr, uint data)
            {
                req_downl_sec = new downl_sec();
                req_downl_sec.head1 = 0xB5;// = 0xB5
                req_downl_sec.head2 = 0x62;// = 0x62;
                req_downl_sec.clas = 0x9;
                req_downl_sec.subclass = 0x21;
                req_downl_sec.length = 0x2C;
                req_downl_sec.startaddr = startaddr;
                req_downl_sec.flags = 0; //0xE008 !!!
                req_downl_sec.data = data;

                return null;
            }

            {
                req_downl_sec = new downl_sec();
                req_downl_sec.head1 = 0xB5;// = 0xB5
                req_downl_sec.head2 = 0x62;// = 0x62;
                req_downl_sec.clas = 0x9;
                req_downl_sec.subclass = 0x21;
                req_downl_sec.length = 0x2C;
                req_downl_sec.startaddr = 0x10000054;//0x2000C4E0
                req_downl_sec.flags = 0; //0xE008 !!!
                req_downl_sec.flags = 0xFFFFFFFF; //0xE008 !!!
                //req_downl_sec.data = 0x2000DD08;//08 DD 00 20
                req_downl_sec.data = 0xFFFFFFFF;
                //B5 62 09 21 2C 00 66 15 BD A8 41 43 84 17 0E 62 78 E1 62 D3 1B 28 64 59 EA 38 C6 25 B2 9E 4C EA 4D 8B 61 4F B5 E8 FC DC 00 20 00 00 00 00 00 00 00 00 03 20
                //B5 62 09 21 2C 00 0C 53 07 9D 34 BA 18 B0 4C 9F 58 C8 FE 82 A8 47 EF 22 FE E2 56 BE AA 0A 64 FE CB 75 66 DE 01 AC FC DC 00 20 00 00 00 00 FF FF FF FF C9 EA
                byte[] data_hash = new byte[32];
                byte[] data_packet = new byte[12];
                var datastruct = StaticUtils.StructureToByteArray(req_downl_sec);
                Array.Copy(datastruct, 38, data_packet, 0, 12);
                data_hash = sha256_sec(data_packet);
                Array.Copy(data_hash, 0, datastruct, 6, 32);

                for (var a = 0; a < data_packet.Length; a++)
                {
                    Console.Write(" " + data_packet[a].ToString("X2"));
                }
                Console.WriteLine();
                for (var a = 0; a < data_hash.Length; a++)
                {
                    Console.Write(" " + data_hash[a].ToString("X2"));
                }
                Console.WriteLine();
                var checksum = ubx_checksum(datastruct, datastruct.Length);
                //port.Write(datastruct, 0, datastruct.Length);
                //port.Write(checksum, 0, checksum.Length);
                for (var a = 0; a < datastruct.Length; a++)
                {
                    Console.Write(" " + datastruct[a].ToString("X2"));
                }
                for (var a = 0; a < checksum.Length; a++)
                {
                    Console.Write(" " + checksum[a].ToString("X2"));
                }
                Console.WriteLine();
                //return;

            }
            var deadline = DateTime.MinValue;
            uint lastaddr = 0;
            //0x2000C4E0
            //req_sec.startaddr = 0x08C;
            //req_sec.startaddr = 0x20000000;
            req_sec.startaddr = 0x20000000;
            //req_sec.startaddr = 0x00800000;
            req_sec.datasize = 0x80;
            //req_sec.flags = 0xFFFFFFFF; //???  0x0
            req_sec.flags = 0x0; //???  0x0

            while (port.IsOpen)
            {
                // determine when to send a new/next request
                if (deadline < DateTime.Now )
                {
                    byte[] data_hash = new byte[32];
                    byte[] data_packet = new byte[12];
                    var datastruct = StaticUtils.StructureToByteArray(req_sec);
                    Array.Copy(datastruct, 38, data_packet, 0, 12);
                    data_hash = sha256_sec(data_packet);
                    Array.Copy(data_hash, 0, datastruct, 6, 32);

                    for (var a = 0; a < data_hash.Length; a++)
                    {
                        //Console.Write(" " + data_hash[a].ToString("X2"));
                    }
                    //Console.WriteLine();

                    //Array.Copy(BitConverter.GetBytes(val1), 0, data, 0, 8);

                    var checksum = ubx_checksum(datastruct, datastruct.Length);
                    port.Write(datastruct, 0, datastruct.Length);
                    port.Write(checksum, 0, checksum.Length);
                    for (var a = 0; a < datastruct.Length; a++)
                    {
                        //Console.Write(" " + datastruct[a].ToString("X2"));
                    }
                    for (var a = 0; a < checksum.Length; a++)
                    {
                        //Console.Write(" " + checksum[a].ToString("X2"));
                    }
                    //Console.WriteLine();


                    deadline = DateTime.Now.AddMilliseconds(20);
 
                }

                Thread.Sleep(0);

                while (port.BytesToRead > 0)
                {
                    var data = (byte) port.ReadByte();

                     //Console.Write("{0,2:x}",data);
                    processbyte(data);
                }

            }
        }


        private static void processbyte(byte data)
        {
            switch (UBX_step) //Normally we start from zero. This is a state machine
            {
                case 0:
                    if (data == 0xB5) // UBX sync char 1
                        UBX_step++; //OH first data packet is correct, so jump to the next step
                    break;
                case 1:
                    if (data == 0x62) // UBX sync char 2
                        UBX_step++; //ooh! The second data packet is correct, jump to the step 2
                    else
                        UBX_step = 0; //Nop, is not correct so restart to step zero and try again.     
                    break;
                case 2:
                    UBX_class = data;
                    ubx_checksum(UBX_class);
                    UBX_step++;
                    break;
                case 3:
                    UBX_id = data;
                    ubx_checksum(UBX_id);
                    UBX_step++;
                    break;
                case 4:
                    UBX_payload_length_hi = data;
                    ubx_checksum(UBX_payload_length_hi);
                    UBX_step++;
                    // We check if the payload lenght is valid...
                    if (UBX_payload_length_hi >= UBX_MAXPAYLOAD)
                    {
                        UBX_step = 0; //Bad data, so restart to step zero and try again.     
                        ck_a = 0;
                        ck_b = 0;
                    }
                    break;
                case 5:
                    UBX_payload_length_lo = data;
                    ubx_checksum(UBX_payload_length_lo);
                    UBX_step++;
                    UBX_payload_counter = 0;
                    break;
                case 6: // Payload data read...
                    if (UBX_payload_counter < UBX_payload_length_hi)
                        // We stay in this state until we reach the payload_length
                    {
                        UBX_buffer[UBX_payload_counter] = data;
                        ubx_checksum(data);
                        UBX_payload_counter++;
                        if (UBX_payload_counter == UBX_payload_length_hi)
                            UBX_step++;
                    }
                    break;
                case 7:
                    UBX_ck_a = data; // First checksum byte
                    UBX_step++;
                    break;
                case 8:
                    UBX_ck_b = data; // Second checksum byte

                    // We end the GPS read...
                    if ((ck_a == UBX_ck_a) && (ck_b == UBX_ck_b))
                    {
                        // Verify the received checksum with the generated checksum.. 
                        // Parse the new GPS packet


                        if (UBX_class == 0x9 && UBX_id == 0x20)
                            {
                             //var resp = UBX_buffer.ByteArrayToStructure<uploadresp>(0);
                             var resp = UBX_buffer.ByteArrayToStructure<uploadresp_9_20_D>(0);
                            for (var a = 0; a < UBX_buffer.Length; a++)
                            {
                                //Console.Write(" " + UBX_buffer[a].ToString("X2"));
                            }
                            Console.WriteLine();
                            Console.Write("0x{0:X8} ", resp.startaddr);
                            Console.Write("0x{0:X2} -> ", resp.datasize);
                            /*
                            Console.Write("0x{0:X8} ", resp.dat0);
                            Console.Write("0x{0:X8} ", resp.dat1);
                            Console.Write("0x{0:X8} ", resp.dat2);
                            Console.WriteLine("0x{0:X8}", resp.dat3);
                            */
                            bw.Seek((int) (resp.startaddr & 0xFFFFF), SeekOrigin.Begin);
                            bw.Write(resp.data, 0, (int)resp.datasize);
                            if (req_sec.startaddr == resp.startaddr) req_sec.startaddr += req_sec.datasize;
                        }
                        else
                        {
                           // Console.WriteLine(DateTime.Now + "we have a packet 0x" + UBX_class.ToString("X") + " 0x" +
                           //                   UBX_id.ToString("X") + " " + UBX_payload_counter);
                        }
                    }
                    // Variable initialization
                    UBX_step = 0;
                    ck_a = 0;
                    ck_b = 0;

                    break;
            }
        }

 
        private static void ubx_checksum(byte ubx_data)
        {
            ck_a += ubx_data;
            ck_b += ck_a;
        }

        private static byte[] ubx_checksum(byte[] packet, int size, int offset = 2)
        {
            uint a = 0x00;
            uint b = 0x00;
            var i = offset;
            while (i < size)
            {
                a += packet[i++];
                b += a;
            }

            var ans = new byte[2];

            ans[0] = (byte) (a & 0xFF);
            ans[1] = (byte) (b & 0xFF);

            return ans;
        }


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private struct uploadresp
        {
            public readonly uint startaddr;
            public readonly uint datasize;
            public readonly uint flags;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)] public readonly byte[] data;
        }

        private struct uploadresp_9_20
        {

            public readonly uint rez;
            public readonly uint rez1;
            public readonly uint rez2;
            public readonly uint rez3;
            public readonly uint rez4;
            public readonly uint rez5;
            public readonly uint rez6;
            public readonly uint rez7;
            public readonly uint startaddr;
            public readonly uint datasize;
            public readonly uint flags;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)] public readonly byte[] data;
        }

        private struct uploadresp_9_20_D
        {

            public readonly uint rez;
            public readonly uint rez1;
            public readonly uint rez2;
            public readonly uint rez3;
            public readonly uint rez4;
            public readonly uint rez5;
            public readonly uint rez6;
            public readonly uint rez7;
            public readonly uint startaddr;
            public readonly uint datasize;
            public readonly uint flags;
            //            public readonly uint dat0;
            //            public readonly uint dat1;
            //            public readonly uint dat2;
            //            public readonly uint dat3;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)] public readonly byte[] data;
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private struct downloadreq
        {
            public byte clas;
            public byte subclass;
            public ushort length;
            public uint startaddr;
            public uint flags;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)] public byte[] data;
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private struct uploadreq
        {
            public byte head1;// = 0xB5 62;
            public byte head2;// = 0x62;
            public byte clas;// = 9;
            public byte subclass;// = 2;
            public ushort length;
            public uint startaddr;
            public uint datasize;
            public uint flags;
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private struct uploadreq_sec
        {
            public byte head1;// = 0xB5 62;
            public byte head2;// = 0x62;
            public byte clas;// = 9;
            public byte subclass;// = 0x20;
            public ushort length;
            //public byte[] hash;
            public UInt64 val1;
            public UInt64 val2;
            public UInt64 val3;
            public UInt64 val4;
            public uint startaddr;
            public uint datasize;
            public uint flags;
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private struct downl_sec
        {
            public byte head1;// = 0xB5 62;
            public byte head2;// = 0x62;
            public byte clas;// = 9;
            public byte subclass;// = 0x21;
            public ushort length;
            public UInt64 val1;
            public UInt64 val2;
            public UInt64 val3;
            public UInt64 val4;
            public uint startaddr;
            public uint flags;
            public uint data;
        }
    }
}
