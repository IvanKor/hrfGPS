#ifndef sha256__h_
#define sha256_h_

/* Remove on a big endian system */
#ifndef LITTLE_ENDIAN
#define LITTLE_ENDIAN
#endif


#ifndef _USRDLL
#define EXPORT_FUNC
#else
#ifdef _WIN32
#define EXPORT_FUNC __declspec(dllexport) __cdecl
#else
#define EXPORT_FUNC
#endif
#endif

typedef struct {
	unsigned int total[2];
	unsigned int state[8];
	unsigned char buffer[64];
} sha256_context;

void EXPORT_FUNC sha256_starts(sha256_context *ctx);
void EXPORT_FUNC sha256_update(sha256_context *ctx, unsigned char *input, unsigned int length);
void EXPORT_FUNC sha256_finish(sha256_context *ctx, unsigned char digest[32]);

#endif /* sha256_h_ */
